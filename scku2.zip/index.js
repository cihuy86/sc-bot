import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from "@sairidev/baileys-new";
import { Boom } from "@hapi/boom";
import pino from "pino";
import chalk from "chalk";
import readline from "readline";
import fs from "fs";
import path from "path";

import config from "./config.js";
import { loadPlugins, handleMessage } from "./lib/pluginHandler.js";
import { pendingAddPlugin, pendingPlaych, pendingYts } from "./lib/pendingState.js";
import { ensureYtDlp } from "./lib/setup-ytdlp.js";
import { cacheViewOnce } from "./lib/viewOnceCache.js";
import { sendRichHtml } from "./lib/RichHtml.js";
import { tryHandleAestheticCommand } from "./lib/aestheticCmd.js";
import { tryHandleButton, checkPendingButtonInput } from "./lib/buttonHandler.js";
import { pendingButtonInput } from "./lib/pendingButton.js";

const logger = pino({ level: "silent" });
const startTime = Date.now();
globalThis.__startTime = startTime;

global.mess = { premium: "🔒 Fitur ini khusus premium." };
global.newsletter = config.newsletter || { id: "", name: "" };

/* ===================== HELPERS ===================== */

function extractBody(content) {
  if (!content) return "";

  // TEXT BIASA
  if (content.conversation) return content.conversation;
  if (content.extendedTextMessage?.text) return content.extendedTextMessage.text;
  if (content.imageMessage?.caption) return content.imageMessage.caption;
  if (content.videoMessage?.caption) return content.videoMessage.caption;

  // BUTTON RESPONSE
  if (content.buttonsResponseMessage?.selectedButtonId)
    return content.buttonsResponseMessage.selectedButtonId;
  if (content.buttonsResponseMessage?.selectedDisplayText)
    return content.buttonsResponseMessage.selectedDisplayText;

  // LIST RESPONSE
  if (content.listResponseMessage?.singleSelectReply?.selectedRowId)
    return content.listResponseMessage.singleSelectReply.selectedRowId;
  if (content.listResponseMessage?.title)
    return content.listResponseMessage.title;

  // TEMPLATE BUTTON
  if (content.templateButtonReplyMessage?.selectedId)
    return content.templateButtonReplyMessage.selectedId;

  // INTERACTIVE RESPONSE (native flow single_select)
  if (content.interactiveResponseMessage) {
    const irm = content.interactiveResponseMessage;
    if (irm.nativeFlowResponseMessage?.paramsJson) {
      try {
        const parsed = JSON.parse(irm.nativeFlowResponseMessage.paramsJson);
        if (parsed.id) return String(parsed.id);
      } catch (e) {
        console.log("[extractBody] parse paramsJson error:", e.message);
      }
    }
    if (irm.body?.text) return irm.body.text;
  }

  // PROTOCOL MESSAGE (edits)
  if (content.protocolMessage?.editedMessage) {
    return extractBody(content.protocolMessage.editedMessage);
  }

  return "";
}

function buildMessage(sock, rawMsg) {
  if (!rawMsg.message) return null;
  const key = rawMsg.key;
  const content = rawMsg.message;
  const chat = key.remoteJid;
  if (!chat) return null;
  const body = extractBody(content);
  return {
    key, raw: rawMsg, message: content, chat, from: chat,
    sender: key.participant || chat,
    isGroup: chat.endsWith("@g.us"),
    body, text: body,
    pushName: rawMsg.pushName || "",
    reply: async (text, opts = {}) =>
      await sock.sendMessage(chat, { text: String(text) }, { quoted: rawMsg, ...opts })
  };
}

/* ============ SOCK EXTENSION ============ */

function attachExtensions(sock) {
  sock.message = {
    send: async (jid, content, opts) => await sock.sendMessage(jid, content, opts)
  };

  sock.sendHtml = async (jid, html, options = {}) => {
    return await sendRichHtml(sock, jid, html, options);
  };
}

/* ===================== PAIRING ===================== */

function askPhoneNumber() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(chalk.bgCyan.black.bold(" 📱 MASUKKAN NOMOR WA ") + chalk.gray(" (contoh: 628xxxxxxxxxx): "), (ans) => {
      rl.close();
      resolve(String(ans).replace(/[^0-9]/g, ""));
    });
  });
}

/* ===================== BOT START ===================== */

let reconnectAttempts = 0;
const MAX_RECONNECT = 15;

async function startBot() {
  if (!fs.existsSync(config.sessionDir)) fs.mkdirSync(config.sessionDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version, logger,
    printQRInTerminal: false,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
    generateHighQualityLinkPreview: true,
    syncFullHistory: false,
    getMessage: async () => ({ conversation: "" })
  });

  attachExtensions(sock);

  if (!sock.authState.creds.registered) {
    const phone = config.pairingNumber || (await askPhoneNumber());
    if (!phone || phone.length < 8) {
      console.log(chalk.red("❌ Nomor tidak valid."));
      process.exit(1);
    }
    await new Promise((r) => setTimeout(r, 3000));
    try {
      const code = await sock.requestPairingCode(phone);
      console.log("\n" + chalk.bgGreen.black.bold("        PAIRING CODE        "));
      console.log(chalk.bgWhite.black.bold(`        ${code}        `));
      console.log(chalk.gray("\nBuka WhatsApp → Perangkat Tertaut → Tautkan Perangkat → Tautkan dengan nomor telepon\n"));
    } catch (e) {
      console.log(chalk.red("❌ Gagal request pairing code:"), e.message);
      process.exit(1);
    }
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;

    for (const raw of messages) {
      try {
        if (!raw.message) continue;
        if (raw.key?.remoteJid === "status@broadcast") continue;

        /* ============ CACHE VIEW ONCE ============ */
        try {
          const msgContent = raw.message || {};
          const wrappers = ["viewOnceMessageV2", "viewOnceMessageV2Extension", "viewOnceMessage"];
          for (const w of wrappers) {
            const inner = msgContent[w]?.message;
            if (!inner) continue;
            const mediaTypes = [
              { key: "imageMessage", type: "image" },
              { key: "videoMessage", type: "video" },
              { key: "audioMessage", type: "audio" }
            ];
            for (const mt of mediaTypes) {
              if (inner[mt.key]) {
                cacheViewOnce(raw.key.id, raw.key.remoteJid, raw.key.participant || raw.key.remoteJid, mt.type, inner[mt.key]);
                break;
              }
            }
            break;
          }
        } catch (cacheErr) {
          console.error("[viewOnceCache] error:", cacheErr.message);
        }

        const chatJid = raw.key?.remoteJid;

        /* ============ HANDLE fromMe ============ */
        if (raw.key?.fromMe) {
          if (!config.allowSelfCommand) continue;
          const selfBody = extractBody(raw.message).trim();

          // DEBUG
          if (!selfBody && raw.message?.interactiveResponseMessage) {
            console.log("[DEBUG] interactiveResponseMessage tapi body kosong");
            console.log("[DEBUG] raw:", JSON.stringify(raw.message.interactiveResponseMessage).slice(0, 500));
          }

          const hasPendingAdd = chatJid && pendingAddPlugin.has(chatJid);
          const hasPendingPl = chatJid && pendingPlaych.has(chatJid);
          const hasPendingYts = chatJid && pendingYts.has(chatJid);
          const hasPendingBtn = chatJid && pendingButtonInput.has(chatJid);
          const isAesthetic = /❰ (?:🎧 ＡＵＤＩＯ|🎬 ＶＩＤＥＯ|▶️ ＰＬＡＹ|🎧 ＰＬＡＹ ＰＩＣＫ) ❱ /i.test(selfBody);
          const isButton = /❰ 🎯 ＢＴＮ ❱ /.test(selfBody);
          const isInteractiveResponse = !!raw.message?.interactiveResponseMessage;
          const isListResponse = !!raw.message?.listResponseMessage;
          const isButtonResponse = !!raw.message?.buttonsResponseMessage;

          if (
            !selfBody.startsWith(config.prefix) &&
            !hasPendingAdd &&
            !hasPendingPl &&
            !hasPendingYts &&
            !hasPendingBtn &&
            !isAesthetic &&
            !isButton &&
            !isInteractiveResponse &&
            !isListResponse &&
            !isButtonResponse
          ) continue;
        }

        const m = buildMessage(sock, raw);
        if (!m) continue;

        console.log("[msg] body:", JSON.stringify(m.body).slice(0, 200));

        /* ============ CEK PENDING BUTTON INPUT ============ */
        const handledPendingInput = await checkPendingButtonInput(sock, m);
        if (handledPendingInput) continue;

        /* ============ CEK BUTTON CLICK ============ */
        const handledButton = await tryHandleButton(sock, m);
        if (handledButton) continue;

        /* ============ CEK AESTHETIC / PLAY PICK ============ */
        const handled = await tryHandleAestheticCommand(sock, m);
        if (handled) continue;

        /* ============ HANDLE COMMAND NORMAL ============ */
        await handleMessage(sock, m, raw);
      } catch (e) {
        console.error(chalk.red("[messages.upsert]"), e);
      }
    }
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      reconnectAttempts = 0;
      console.log(chalk.green.bold("\n✅ Bot terhubung ke WhatsApp!"));
      console.log(chalk.cyan(`🤖 Nama Bot : ${config.botName}`));
      console.log(chalk.cyan(`📞 Nomor    : ${sock.user?.id?.split(":")[0] || "-"}`));
      console.log(chalk.cyan(`⚡ Prefix   : ${config.prefix}`));
      console.log(chalk.gray(`🕐 Uptime mulai...\n`));
    }

    if (connection === "close") {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const loggedOut = code === DisconnectReason.loggedOut;
      const restartRequired = code === DisconnectReason.restartRequired;
      console.log(chalk.red(`\n❌ Koneksi ditutup. Status: ${code}`));

      if (loggedOut) {
        console.log(chalk.red.bold("🚪 Logged out. Hapus folder ./session lalu jalankan ulang."));
        process.exit(0);
      }

      if (restartRequired) {
        startBot();
        return;
      }

      if (reconnectAttempts < MAX_RECONNECT) {
        reconnectAttempts++;
        const delay = Math.min(5000 * reconnectAttempts, 30000);
        console.log(chalk.yellow(`🔄 Reconnect #${reconnectAttempts} dalam ${delay / 1000}s...`));
        setTimeout(() => startBot(), delay);
      } else {
        console.log(chalk.red("❌ Reconnect limit tercapai. Exit."));
        process.exit(1);
      }
    }
  });

  return sock;
}

/* ===================== BOOT ===================== */

(async () => {
  console.clear();
  console.log(chalk.cyan.bold(`
╭───────────────────────────────────────╮
│        ✦  ${config.botName}  ✦         
│        WhatsApp Bot • Baileys         
╰───────────────────────────────────────╯
`));

  console.log(chalk.yellow("📂 Loading plugins..."));
  await loadPlugins("./plugins");

  console.log(chalk.yellow("\n🔧 Setup tools..."));
  await ensureYtDlp();

  await startBot();
})();

process.on("uncaughtException", (e) =>
  console.error(chalk.red("[uncaughtException]"), e)
);
process.on("unhandledRejection", (e) =>
  console.error(chalk.red("[unhandledRejection]"), e)
);

export { startTime };