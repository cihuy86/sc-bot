'use strict';

import axios from "axios";
import sharp from "sharp";
import fs from "fs";
import path from "path";
import ff from "fluent-ffmpeg";
import ffmpegPath from "@ffmpeg-installer/ffmpeg";
import { addExif } from "../../lib/exif.js";
import config from "../../config.js";

ff.setFfmpegPath(ffmpegPath.path);

/* ============ HELPER: GIF → WEBP 512 ============ */
function gifToWebp512(gifBuffer, trashDir) {
  return new Promise((resolve, reject) => {
    const tmpIn = path.join(trashDir, `brat_${Date.now()}_in.gif`);
    const tmpOut = path.join(trashDir, `brat_${Date.now()}_out.webp`);
    fs.writeFileSync(tmpIn, gifBuffer);

    ff(tmpIn)
      .on("error", (err) => {
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
        if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
        reject(err);
      })
      .on("end", () => {
        try {
          const buff = fs.readFileSync(tmpOut);
          if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
          if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
          resolve(buff);
        } catch (e) {
          reject(e);
        }
      })
      .addOutputOptions([
        "-vcodec", "libwebp",
        "-vf", "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0,split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
        "-loop", "0",
        "-preset", "default",
        "-an",
        "-vsync", "0"
      ])
      .toFormat("webp")
      .save(tmpOut);
  });
}

/* ============================================================ */
/* ============ HANDLER ============ */
/* ============================================================ */
async function handle(client, messageInfo) {
  const { m, args, command } = messageInfo;
  const text = (args || []).join(" ").trim();

  // ============================================================
  // ============ CODE ASLI LU — GAK DIUBAH ============
  // ============================================================
  {
    if (!text) {
      return m.reply(`— ex: ${config.prefix}${command} teksnya`);
    }

    await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const packname = config.packname || "SIX CORE";
    const author = config.author || "Bot";

    const trashDir = path.join(process.cwd(), "lib", "sampah");
    if (!fs.existsSync(trashDir)) {
      fs.mkdirSync(trashDir, { recursive: true });
    }

    try {
      if (command === "brat") {
        const url = `https://brat.siputzx.my.id/image?text=${encodeURIComponent(text)}`;
        const res = await axios.get(url, { responseType: "arraybuffer" });

        const resizedWebp = await sharp(Buffer.from(res.data))
          .resize(512, 512, {
            fit: "contain",
            background: { r: 255, g: 255, b: 255, alpha: 1 }
          })
          .webp({ quality: 95 })
          .toBuffer();

        const stickerFinal = await addExif(resizedWebp, packname, author);

        await client.sendMessage(m.chat, { sticker: stickerFinal }, { quoted: m.raw });
        return await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      }

      if (command === "bratvid") {
        const url = `https://brat.siputzx.my.id/gif?text=${encodeURIComponent(text)}`;
        const res = await axios.get(url, { responseType: "arraybuffer" });

        const rawWebpAnim = await gifToWebp512(Buffer.from(res.data), trashDir);
        const stickerFinal = await addExif(rawWebpAnim, packname, author);

        await client.sendMessage(m.chat, { sticker: stickerFinal }, { quoted: m.raw });
        return await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      }
    } catch (err) {
      console.error("BRAT ERROR:", err);
      await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return m.reply(`❌ Gagal membuat sticker brat: ${err.message}`);
    }
  }
  // ============================================================
  // ============ END CODE ASLI ============
  // ============================================================
}

export default {
  handle,
  Commands: ["brat", "bratvid"],
  OnlyPremium: false,
  OnlyOwner: false
};