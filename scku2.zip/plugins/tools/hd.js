'use strict';

import { downloadContentFromMessage } from "@sairidev/baileys-new";
import config from "../../config.js";
import { getActiveKey } from "../../lib/apikeys.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

function getImageFromMessage(m) {
  const msg = m.message || {};
  if (msg.imageMessage) return { media: msg.imageMessage, source: "direct" };

  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.documentMessage?.contextInfo;

  if (ctx?.quotedMessage?.imageMessage) {
    return { media: ctx.quotedMessage.imageMessage, source: "quoted" };
  }
  return null;
}

async function downloadMedia(mediaObj, type) {
  const stream = await downloadContentFromMessage(mediaObj, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  const found = getImageFromMessage(m);
  const mime = found?.media?.mimetype || "";

  if (!found || !mime || !mime.startsWith("image/")) {
    return m.reply(`✨ *HD ENHANCER / REMINI (v1)*\n\nBalas atau kirim gambar yang buram dengan perintah: *${usedPrefix + command}*\n\nOpsi skala:\n*${usedPrefix + command} 4* (Skala 4x)`);
  }

  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    m.reply("⏳ Meningkatkan resolusi gambar... Mohon tunggu sebentar.");

    const media = await downloadMedia(found.media, "image");
    if (!media) throw new Error("Gagal mengunduh gambar.");

    const scale = text && text.trim() === "4" ? "4" : "2";

    const apiKey = getActiveKey();
    if (!apiKey) throw new Error("Belum ada API key. Set dulu pakai .apikey add <key>");

    const form = new FormData();
    form.append("file", new Blob([media], { type: mime }), "image.jpg");
    form.append("scale", scale);

    const apiUrl = `${JEREXD_BASE}/api/tools/hd?apikey=${apiKey}`;

    const res = await fetch(apiUrl, { method: "POST", body: form });
    const json = await res.json();
    console.log("[hd] response:", JSON.stringify(json).slice(0, 300));

    if (!json.status) throw new Error(json.error || json.message || "Gagal memproses HD gambar.");

    const upscaledUrl = json.result?.upscaled_url || json.result?.url;
    if (!upscaledUrl) throw new Error("URL gambar HD tidak ditemukan.");

    const imgRes = await fetch(upscaledUrl);
    const imgBuffer = Buffer.from(await imgRes.arrayBuffer());

    const caption = `✨ *HD ENHANCER (v1 - ${json.result?.scale_applied || scale + "x"})*\n\n`;
    const fullCaption = caption + `✅ *Request by:* ${m.pushName || "User"}`;

    await conn.sendMessage(
      m.chat,
      { image: imgBuffer, caption: fullCaption },
      { quoted: m.raw }
    );

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
    console.error("[hd]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply(`❌ *HD Gagal*\nError: ${e.message}`);
  }
}

export default {
  handle,
  Commands: ["hd", "remini", "hdr", "upscale", "jernih"],
  OnlyPremium: false,
  OnlyOwner: false
};