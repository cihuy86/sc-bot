'use strict';

import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ DETEKSI URL PINTEREST ============ */
function isPinterestUrl(str) {
  return /https?:\/\/(www\.)?(id\.)?(pinterest\.(com|co\.[a-z]{2}|[a-z]{2})|pin\.it)/i.test(str);
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  if (!text || !text.trim()) {
    return reply(m,
`⚠️ *Masukkan kata kunci foto/gambar yang ingin dicari di Pinterest!*

*Contoh:*
• \`${usedPrefix}${command} windah basudara\`
• \`${usedPrefix}${command} anime aesthetic\``);
  }

  const query = text.trim();
  const apiKey = getActiveKey();

  if (!apiKey) {
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
  }

  /* ============================================================ */
  /* ============ MODE 1: URL PINTEREST (DOWNLOAD) ============ */
  /* ============================================================ */
  if (isPinterestUrl(query)) {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});

    try {
      const res = await fetch(
        `${JEREXD_BASE}/api/downloader/pin?apikey=${apiKey}&url=${encodeURIComponent(query)}`,
        { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(60000) }
      );
      const json = await res.json();
      console.log("[pin] download response:", JSON.stringify(json).slice(0, 300));

      if (!json.status || !json.result) {
        throw new Error(json.error || 'Gagal memproses link Pinterest');
      }

      const resData = json.result;
      const mediaUrl =
        resData.url ||
        resData.download_url ||
        resData.image ||
        resData.video ||
        (typeof resData === 'string' ? resData : null);

      if (!mediaUrl) throw new Error('Media tidak ditemukan');

      const isVideo = resData.type === 'video' || /\.(mp4|mov|avi)($|\?)/i.test(mediaUrl);
      const caption = `📌 *PINTEREST DOWNLOADER*\n\n✨ *Request by:* ${m.pushName || 'User'}`;

      if (isVideo) {
        await conn.sendMessage(m.chat, {
          video: { url: mediaUrl },
          caption
        }, { quoted: m.raw });
      } else {
        await conn.sendMessage(m.chat, {
          image: { url: mediaUrl },
          caption
        }, { quoted: m.raw });
      }

      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});
      return;

    } catch (e) {
      console.error("[pin:download]", e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
      return reply(m, `❌ Gagal download: ${e.message}`);
    }
  }

  /* ============================================================ */
  /* ============ MODE 2: SEARCH (ALBUM 5 FOTO) ============ */
  /* ============================================================ */
  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});

  try {
    const res = await fetch(
      `${JEREXD_BASE}/api/search/pin?apikey=${apiKey}&q=${encodeURIComponent(query)}&limit=25`,
      { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(60000) }
    );
    const json = await res.json();
    console.log("[pin] search response:", JSON.stringify(json).slice(0, 300));

    const pins = json.result?.pins || json.result || json.data || [];

    if (!json.status || !pins.length) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
      return reply(m, `❌ Foto Pinterest tidak ditemukan untuk kata kunci: "${query}"`);
    }

    // ambil 5 foto berkualitas terbaik
    const validPins = pins.filter(p => p && (p.image || p.url)).slice(0, 5);

    if (!validPins.length) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
      return reply(m, "❌ Tidak ditemukan gambar Pinterest yang valid.");
    }

    /* ============ CARA 1: kalau ada sendAlbum, pakai ============ */
    if (typeof conn.sendAlbum === 'function' && validPins.length > 1) {
      try {
        const albumItems = validPins.map((p, idx) => {
          const imgUrl = p.image || p.url;
          if (idx === 0) {
            return {
              image: { url: imgUrl },
              caption: `📌 *PINTEREST ALBUM SEARCH*\n\n` +
                       `• *Pencarian:* ${query}\n` +
                       `• *Hasil Ditemukan:* ${validPins.length} Foto\n` +
                       `• *Judul:* ${p.title || query}\n` +
                       (p.url ? `• 🔗 *Link:* ${p.url}\n` : '') +
                       `\n✨ *Request by:* ${m.pushName || 'User'}`
            };
          }
          return {
            image: { url: imgUrl },
            caption: `📌 *${p.title || `${query} (${idx + 1})`}*\n${p.url ? `🔗 ${p.url}` : ''}`
          };
        });

        await conn.sendAlbum(m.chat, albumItems, { quoted: m.raw, delay: 350 });
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});
        return;
      } catch (albumErr) {
        console.warn("[pin] sendAlbum gagal, fallback kirim satu-satu:", albumErr.message);
      }
    }

    /* ============ CARA 2: fallback kirim 5 gambar satu-satu ============ */
    await reply(m, `📸 Menemukan *${validPins.length}* foto Pinterest, sedang mengirim...`);

    for (let i = 0; i < validPins.length; i++) {
      const p = validPins[i];
      const imgUrl = p.image || p.url;

      const cap = i === 0
        ? `📌 *PINTEREST SEARCH*\n\n` +
          `• *Pencarian:* ${query}\n` +
          `• *Hasil:* ${validPins.length} Foto\n` +
          `• *Judul:* ${p.title || query}\n` +
          (p.url ? `• 🔗 *Link:* ${p.url}\n` : '') +
          `\n✨ *Request by:* ${m.pushName || 'User'}`
        : `📌 *${p.title || `${query} (${i + 1})`}*${p.url ? `\n🔗 ${p.url}` : ''}`;

      try {
        await conn.sendMessage(m.chat, {
          image: { url: imgUrl },
          caption: cap
        }, { quoted: i === 0 ? m.raw : undefined });

        // delay 600ms antar foto biar gak rate limit
        if (i < validPins.length - 1) {
          await new Promise((r) => setTimeout(r, 600));
        }
      } catch (imgErr) {
        console.warn(`[pin] gagal kirim foto ${i + 1}:`, imgErr.message);
      }
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});

  } catch (e) {
    console.error('[pin:search]', e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
    reply(m, "❌ Gagal mencari album gambar di Pinterest: " + (e.message || 'Coba lagi nanti.'));
  }
}

export default {
  handle,
  Commands: ["pin", "pinterest", "pinalbum", "pinsearch"],
  OnlyPremium: false,
  OnlyOwner: false
};