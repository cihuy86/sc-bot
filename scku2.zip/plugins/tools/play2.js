'use strict';

import { randomUUID } from 'crypto';
import axios from 'axios';
import { Innertube } from 'youtubei.js';

import { buildMusicPlayerHtml } from '../../lib/Components/MusicPlayerCard.js';
import { sendRichHtml } from '../../lib/Components/RichHtml.js';
import { resizeImage } from '../../lib/Utilities.js';
import config from '../../config.js';

let youtube = null;
async function getYoutube() {
  if (!youtube) youtube = await Innertube.create();
  return youtube;
}

/* ============ RESOLVE AUDIO URL VIA SCRIPTMIND ============ */
async function resolvePreview(url) {
  const guestId = randomUUID();
  const response = await axios.post(
    'https://scriptmind.co/api/media/resolve/preview',
    { url, platform: 'youtube', pageType: 'video', guestId },
    { headers: { 'Content-Type': 'application/json' }, timeout: 60000 }
  );
  return response.data;
}

/* ============ SEARCH + RESOLVE SATU LAGU ============ */
async function processTrack(query) {
  const yt = await getYoutube();
  const search = await yt.search(query, { type: 'video' });
  const video = search.videos?.[0];
  if (!video) throw new Error('Video tidak ditemukan');

  const videoId = video.id;
  const url = `https://www.youtube.com/watch?v=${videoId}`;

  const resolved = await resolvePreview(url);
  if (!resolved?.success) {
    throw new Error(resolved?.message || 'Gagal resolve audio');
  }

  let media;
  try {
    media = typeof resolved.result.resolvedMediaJson === 'string'
      ? JSON.parse(resolved.result.resolvedMediaJson)
      : resolved.result.resolvedMediaJson;
  } catch {
    throw new Error('Gagal parse media JSON');
  }

  const audioUrl = media?.tunnel?.[1];
  if (!audioUrl) throw new Error('URL audio tidak ditemukan');

  const title = video.title?.text || query;
  const artist = video.author?.name || video.author?.text || 'YouTube';

  // thumbnail — cari yang paling gede
  const thumbs = video.thumbnails || [];
  const thumbUrl = thumbs[thumbs.length - 1]?.url || null;

  let cover = '';
  if (thumbUrl) {
    try {
      const resized = await resizeImage(thumbUrl, 300, 300, 75, 'jpeg');
      cover = 'data:image/jpeg;base64,' + resized.toString('base64');
    } catch (e) {
      console.log('[play2] cover gagal:', e.message);
    }
  }

  // WebSocket URL
  const wsUrl = 'wss://kyzorohan.web.id/?url=' + encodeURIComponent(audioUrl);

  return {
    title,
    artist,
    album: 'YouTube',
    cover,
    audio: '',          // kosong, karena pakai WebSocket
    wsUrl
  };
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const isPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  if (!text) {
    return m.reply(`👉🏻 *Example*: ${isPrefix}${command} raindance\n\nBeberapa lagu sekaligus, pisah pakai \`#\`:\n${isPrefix}${command} raindance # about you # sialan`);
  }

  const allQuery = text.split('#').map(q => q.trim()).filter(Boolean);
  const queries = allQuery.slice(0, 4);
  const isMulti = queries.length > 1;

  if (allQuery.length > 4) {
    await m.reply(`⚠️ Max 4 lagu per card.`);
  }

  await sock.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

  try {
    const tracks = [];
    const failed = [];

    for (const query of queries) {
      try {
        console.log(`[play2] processing: ${query}`);
        const track = await processTrack(query);
        tracks.push(track);
      } catch (e) {
        console.error(`[play2] "${query}" failed:`, e.message);
        failed.push(query);
      }
    }

    if (!tracks.length) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return m.reply(`❌ No song found for "${text}".`);
    }

    const html = buildMusicPlayerHtml({ tracks });
    const cardTitle = isMulti
      ? `${tracks.length} Songs - ${tracks[0].title}`
      : `${tracks[0].title} - ${tracks[0].artist}`;

    await sendRichHtml(sock, m.chat, html, { title: cardTitle });
    await sock.sendMessage(m.chat, { react: { text: "🎵", key: m.key } });

    if (failed.length) {
      await m.reply(`⚠️ Not found: ${failed.join(', ')}`);
    }
  } catch (error) {
    console.error('❌ play2 failed:', error);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply(`❌ Gagal: ${error.message}`);
  }
}

export default {
  handle,
  Commands: ["play2", "p2"],
  OnlyPremium: false,
  OnlyOwner: false
};