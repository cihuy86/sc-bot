'use strict';

import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  if (!text) {
    return reply(m,
`*Format salah!*

📌 *Contoh:*
\`${usedPrefix}${command} https://www.youtube.com/watch?v=xxxx [quality]\`

*Quality:* 360, 480, 720, 1080`);
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});

  try {
    const apiKey = getActiveKey();
    if (!apiKey) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    const parts = text.trim().split(' ');
    const targetUrl = parts[0];
    const quality = parts[1] || "720";

    const apiUrl = `${JEREXD_BASE}/api/downloader/ytmp4?apikey=${apiKey}&url=${encodeURIComponent(targetUrl)}&quality=${encodeURIComponent(quality)}`;
    console.log("[ytmp4] calling:", apiUrl.slice(0, 150));

    const res = await fetch(apiUrl, {
      headers: { "User-Agent": "Mozilla/5.0" },
      signal: AbortSignal.timeout(60000)
    });

    const json = await res.json();
    console.log("[ytmp4] response:", JSON.stringify(json).slice(0, 400));

    if (!json.status) {
      throw new Error(json.error || json.message || 'Gagal mengunduh video YouTube');
    }

    const videoUrl = json.downloadUrl || json.url || json.result?.downloadUrl || json.result?.url;
    if (!videoUrl) throw new Error('Link video YouTube tidak ditemukan');

    const title = json.title || json.result?.title || 'YouTube Video';

    const caption = `🎬 *${config.botName || 'BOT'} - YOUTUBE MP4 DOWNLOADER*\n\n` +
      `📌 *Judul:* ${title}\n` +
      `📺 *Kualitas:* ${quality}p\n` +
      `✨ *Request by:* ${m.pushName || 'User'}`;

    try {
      await conn.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: caption,
        fileName: `${title.slice(0, 30) || 'video'}.mp4`
      }, { quoted: m.raw });
    } catch (e) {
      console.warn('[ytmp4] gagal kirim sebagai video, fallback ke document:', e.message);
      await conn.sendMessage(m.chat, {
        document: { url: videoUrl },
        fileName: `${title.slice(0, 30) || 'video'}.mp4`,
        mimetype: 'video/mp4',
        caption: caption
      }, { quoted: m.raw });
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});

  } catch (e) {
    console.error("[ytmp4]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
    reply(m, `❌ *Error:* ${e.message || 'Terjadi kesalahan pada server'}`);
  }
}

export default {
  handle,
  Commands: ["ytmp4", "ytv", "ytmp4api"],
  OnlyPremium: false,
  OnlyOwner: false
};