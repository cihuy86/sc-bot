'use strict';

import { downloadContentFromMessage } from "@sairidev/baileys-new";
import uploadImage from "../../lib/uploadImage.js";
import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ GET IMAGE FROM MESSAGE ============ */
function getImageFromMessage(m) {
  const msg = m.message || {};
  if (msg.imageMessage) return { media: msg.imageMessage, mime: msg.imageMessage.mimetype };

  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.documentMessage?.contextInfo;

  if (ctx?.quotedMessage?.imageMessage) {
    return { media: ctx.quotedMessage.imageMessage, mime: ctx.quotedMessage.imageMessage.mimetype };
  }

  return null;
}

async function downloadMedia(mediaObj, type) {
  const stream = await downloadContentFromMessage(mediaObj, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";

  try {
    const prompt = (args || []).join(" ").trim();
    if (!prompt) {
      return reply(m, `⚠️ Masukkan prompt editan!\nContoh: \`${usedPrefix}${command} ubah jadi rambut merah\``);
    }

    const found = getImageFromMessage(m);
    const mime = found?.mime || "";

    if (!found || !/image/.test(mime)) {
      return reply(m, `⚠️ Reply gambar dengan caption \`${usedPrefix}${command} <prompt>\``);
    }

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const media = await downloadMedia(found.media, "image");
    if (!media || media.length === 0) {
      throw new Error("Media kosong / gagal download");
    }

    /* ============ UPLOAD GAMBAR ============ */
    let url;
    try {
      url = await uploadImage(media);
    } catch (e) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, "❌ Gagal mengupload gambar ke server temporary. Coba lagi.");
    }

    /* ============ AMBIL API KEY ============ */
    const apiKey = getActiveKey();
    if (!apiKey) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    /* ============ CALL API ============ */
    const apiUrl = `${JEREXD_BASE}/api/ai/editimage?apikey=${apiKey}&prompt=${encodeURIComponent(prompt)}&url=${encodeURIComponent(url)}`;
    console.log("[aiedit] calling API...");

    const response = await fetch(apiUrl, {
      headers: { "User-Agent": "Mozilla/5.0" },
      timeout: 60000
    });
    const json = await response.json();
    console.log("[aiedit] response:", JSON.stringify(json).slice(0, 300));

    if (!json.status) {
      throw new Error(json.error || json.message || json.detail || "Gagal mengedit gambar");
    }

    let resultUrl = json.result?.image || json.result?.url || json.result?.images?.[0] || json.data?.image || json.data?.url || (Array.isArray(json.result) ? json.result[0] : json.result) || json.data;
    if (typeof resultUrl === 'object' && resultUrl !== null) {
      resultUrl = resultUrl.url || resultUrl.image || JSON.stringify(resultUrl);
    }

    if (typeof resultUrl === 'string' && resultUrl.startsWith('http')) {
      await conn.sendMessage(m.chat, {
        image: { url: resultUrl },
        caption: `✅ *AI Edit Success!*\n📝 *Prompt:* ${prompt}`
      }, { quoted: m.raw }).catch(() => reply(m, "Gagal mengirim media, ini linknya: " + resultUrl));

      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } else {
      throw new Error("Format URL hasil gambar tidak valid");
    }
  } catch (e) {
    console.error("[aiedit]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    reply(m, "❌ Error: " + (e.message || e));
  }
}

export default {
  handle,
  Commands: ["aiedit", "editgambar"],
  OnlyPremium: false,
  OnlyOwner: false
};