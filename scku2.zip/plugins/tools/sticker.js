'use strict';

import sharp from "sharp";
import fs from "fs";
import path from "path";
import ff from "fluent-ffmpeg";
import ffmpegPath from "@ffmpeg-installer/ffmpeg";
import { downloadContentFromMessage } from "@sairidev/baileys-new";
import { addExif } from "../../lib/exif.js";
import config from "../../config.js";

ff.setFfmpegPath(ffmpegPath.path);

const MAX_VIDEO_SECONDS = 8;
const MAX_VIDEO_SIZE = 5 * 1024 * 1024;

/* ============ AMBIL MEDIA DARI PESAN ============ */
function getMediaFromMessage(m) {
  const msg = m.message || {};

  if (msg.imageMessage) return { type: "image", media: msg.imageMessage };
  if (msg.videoMessage) return { type: "video", media: msg.videoMessage };
  if (msg.stickerMessage) return { type: "sticker", media: msg.stickerMessage };

  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.stickerMessage?.contextInfo;

  if (ctx?.quotedMessage) {
    const q = ctx.quotedMessage;
    if (q.imageMessage) return { type: "image", media: q.imageMessage };
    if (q.videoMessage) return { type: "video", media: q.videoMessage };
    if (q.stickerMessage) return { type: "sticker", media: q.stickerMessage };
  }

  return null;
}

/* ============ DOWNLOAD MEDIA ============ */
async function downloadMedia(mediaObj, type) {
  const stream = await downloadContentFromMessage(mediaObj, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

/* ============ IMAGE → WEBP ============ */
async function imageToWebp(buffer) {
  return await sharp(buffer)
    .resize(512, 512, {
      fit: "contain",
      background: { r: 0, g: 0, b: 0, alpha: 0 }
    })
    .webp({ quality: 90 })
    .toBuffer();
}

/* ============ VIDEO → WEBP ============ */
function videoToWebp(videoBuffer, tmpDir) {
  return new Promise((resolve, reject) => {
    const ts = Date.now();
    const tmpIn = path.join(tmpDir, `stk_${ts}_in.mp4`);
    const tmpOut = path.join(tmpDir, `stk_${ts}_out.webp`);

    fs.writeFileSync(tmpIn, videoBuffer);

    const timeout = setTimeout(() => {
      cleanup(tmpIn, tmpOut);
      reject(new Error("Proses convert video timeout (60s)"));
    }, 60000);

    function cleanup(...files) {
      files.forEach((f) => { try { fs.unlinkSync(f); } catch {} });
    }

    ff(tmpIn)
      .on("start", () => console.log("[sticker:ffmpeg] mulai convert..."))
      .on("progress", (p) => {
        if (p.percent) console.log(`[sticker:ffmpeg] ${p.percent.toFixed(1)}%`);
      })
      .on("error", (err) => {
        clearTimeout(timeout);
        console.error("[sticker:ffmpeg] error:", err.message);
        cleanup(tmpIn, tmpOut);
        reject(new Error(`FFmpeg gagal: ${err.message}`));
      })
      .on("end", () => {
        clearTimeout(timeout);
        try {
          if (!fs.existsSync(tmpOut)) throw new Error("Output WebP gak ke-generate");
          const buff = fs.readFileSync(tmpOut);
          cleanup(tmpIn, tmpOut);

          if (!buff || buff.length < 100) throw new Error("Output WebP kosong");

          console.log(`[sticker:ffmpeg] ✅ selesai (${(buff.length / 1024).toFixed(1)} KB)`);
          resolve(buff);
        } catch (e) {
          reject(e);
        }
      })
      .inputOptions(["-t", String(MAX_VIDEO_SECONDS)])
      .outputOptions([
        "-vcodec", "libwebp",
        "-vf", "scale=320:320:force_original_aspect_ratio=decrease,fps=12,pad=320:320:-1:-1:color=white@0.0,split [a][b]; [a] palettegen=max_colors=128:reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse=dither=bayer",
        "-loop", "0",
        "-preset", "default",
        "-an",
        "-vsync", "0",
        "-q:v", "70",
        "-compression_level", "6",
        "-threads", "2"
      ])
      .toFormat("webp")
      .save(tmpOut);
  });
}

/* ============================================================ */
/* ============ HANDLER ============ */
/* ============================================================ */
async function handle(sock, messageInfo) {
  const { m } = messageInfo;

  const found = getMediaFromMessage(m);

  if (!found) {
    return m.reply(
      `⚠️ *Format salah.*\n\n` +
      `*Cara pakai:*\n` +
      `• Kirim/tag foto + caption \`${config.prefix}s\`\n` +
      `• Kirim/tag video (max 8 detik) + caption \`${config.prefix}s\`\n` +
      `• Reply foto/video → ketik \`${config.prefix}s\``
    );
  }

  if (found.type === "sticker") {
    return m.reply("⚠️ Yang lu kirim/reply udah sticker.");
  }

  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  const packname = config.packname || "SIX CORE";
  const author = config.author || "Bot";
  const trashDir = path.join(process.cwd(), "lib", "sampah");
  if (!fs.existsSync(trashDir)) fs.mkdirSync(trashDir, { recursive: true });

  try {
    if (found.type === "video") {
      const seconds = found.media.seconds || 0;
      console.log(`[sticker] video durasi: ${seconds}s`);
      if (seconds > MAX_VIDEO_SECONDS + 2) {
        throw new Error(`Video terlalu panjang (${seconds}s). Max ${MAX_VIDEO_SECONDS} detik.`);
      }
    }

    const buffer = await downloadMedia(found.media, found.type);
    if (!buffer || buffer.length === 0) throw new Error("File media kosong");

    console.log(`[sticker] size: ${(buffer.length / 1024 / 1024).toFixed(2)} MB`);

    if (found.type === "video" && buffer.length > MAX_VIDEO_SIZE) {
      throw new Error(`Video terlalu besar (${(buffer.length / 1024 / 1024).toFixed(1)} MB). Max ${MAX_VIDEO_SIZE / 1024 / 1024} MB.`);
    }

    let webpBuffer;
    if (found.type === "image") {
      webpBuffer = await imageToWebp(buffer);
    } else if (found.type === "video") {
      webpBuffer = await videoToWebp(buffer, trashDir);
    }

    const stickerFinal = await addExif(webpBuffer, packname, author);

    await sock.sendMessage(m.chat, { sticker: stickerFinal }, { quoted: m.raw });
    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (err) {
    console.error("[sticker] error:", err);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    return m.reply(`❌ Gagal membuat sticker: ${err.message}`);
  }
}

export default {
  handle,
  Commands: ["s", "stiker", "sticker", "stik"],
  OnlyPremium: false,
  OnlyOwner: false
};