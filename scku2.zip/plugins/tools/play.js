'use strict';

import axios from 'axios';
import yts from 'yt-search';
import { reply } from '../../lib/utils.js';
import { getActiveKey } from '../../lib/apikeys.js';
import config from '../../config.js';

const JEREXD_BASE = 'https://api.jerexd.my.id';

/* ============================================================ */
/* ============ GET AUDIO (multi-endpoint) ============ */
/* ============================================================ */
async function getYouTubeAudio(url) {
  const API_KEY = getActiveKey();
  const errors = [];

  /* ===== LIST ENDPOINT YANG DICOBA ===== */
  const endpoints = [
    {
      name: "ytmp3v2",
      path: "/api/downloader/ytmp3v2",
      params: { apikey: API_KEY, url, format: 'mp3' }
    },
    {
      name: "ytmp3",
      path: "/api/downloader/ytmp3",
      params: { apikey: API_KEY, url }
    },
    {
      name: "youtube",
      path: "/api/downloader/youtube",
      params: { apikey: API_KEY, url, format: 'mp3' }
    }
  ];

  for (const ep of endpoints) {
    try {
      console.log(`[play] coba ${ep.name}...`);
      const res = await axios.get(`${JEREXD_BASE}${ep.path}`, {
        params: ep.params,
        timeout: 30000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });

      console.log(`[play] ${ep.name} status:`, res.data?.status);

      if (res.data?.status) {
        const data = res.data.result || res.data.data || res.data;
        const dl = data.download || data.url || data.downloadUrl || data.download_url;

        if (dl) {
          console.log(`[play] ✅ ${ep.name} OK`);
          return {
            title: data.title || 'YouTube Audio',
            author: data.channel || data.author || 'YouTube',
            duration: data.duration || '-',
            thumbnail: data.thumbnail || `https://i.ytimg.com/vi/${data.id || data.video_id || ''}/hqdefault.jpg`,
            downloadUrl: dl
          };
        }
      }

      errors.push(`${ep.name}: no download url`);
    } catch (e) {
      console.log(`[play] ❌ ${ep.name} gagal:`, e.message);
      errors.push(`${ep.name}: ${e.message}`);
    }
  }

  throw new Error(`Semua endpoint gagal:\n${errors.join("\n")}`);
}

/* ============================================================ */
/* ============ SEARCH YOUTUBE ============ */
/* ============================================================ */
async function searchYoutube(query) {
  try {
    const searchResults = await yts(query);
    if (!searchResults?.videos?.length) {
      throw new Error('Tidak ditemukan hasil');
    }
    return searchResults.videos.slice(0, 5);
  } catch (error) {
    try {
      const API_KEY = getActiveKey();
      const res = await axios.get(`${JEREXD_BASE}/api/search/youtube`, {
        params: { apikey: API_KEY, q: query },
        timeout: 20000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });

      if (res.data?.status && Array.isArray(res.data.result) && res.data.result.length > 0) {
        return res.data.result.slice(0, 5).map(v => ({
          title: v.title,
          author: { name: v.channel || 'YouTube' },
          timestamp: v.duration || '-',
          views: 0,
          thumbnail: v.imageUrl || '',
          url: v.link || `https://youtube.com/watch?v=${v.id}`
        }));
      }
    } catch {}
    throw error;
  }
}

/* ============================================================ */
/* ============ SEND PICKER LIST ============ */
/* ============================================================ */
async function sendPickerList(sock, m, videos, query) {
  const sections = [{
    title: "🎧 Pilih Lagu Yang Ingin Didownload",
    rows: videos.map((v, i) => ({
      title: `${i + 1}. ${String(v.title).substring(0, 40)}`,
      description: `📺 ${v.author?.name || 'YouTube'} | ⏳ ${v.timestamp || '-'}`,
      id: `❰ 🎧 ＰＬＡＹ ＰＩＣＫ ❱ ${v.url}`
    }))
  }];

  const listText =
    `🎵 *${config.botName || 'BOT'} - YOUTUBE MUSIC SEARCH*\n\n` +
    `🔍 *Query:* ${query}\n` +
    `📌 *Ditemukan:* ${videos.length} hasil\n\n` +
    videos.map((v, i) =>
      `*${i + 1}.* ${v.title}\n   👤 ${v.author?.name || 'YouTube'}\n   ⏱️ ${v.timestamp || '-'}`
    ).join('\n\n');

  try {
    const msgContent = {
      interactiveMessage: {
        header: { title: "🎵 YouTube Music Search", hasMediaAttachment: false },
        body: { text: `🔍 *${query}*` },
        footer: { text: config.botName || 'BOT' },
        nativeFlowMessage: {
          buttons: [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "🎧 Pilih Lagu",
              sections
            })
          }]
        }
      }
    };
    await sock.relayMessage(m.chat, msgContent, { quoted: m.raw });
    console.log("[play] ✅ native picker sent");
    return true;
  } catch (e) {
    console.log("[play] ❌ native picker gagal, fallback text:", e.message);
  }

  await reply(m, listText);
  return false;
}

/* ============================================================ */
/* ============ HANDLER ============ */
/* ============================================================ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  try {
    const API_KEY = getActiveKey();

    if (!text) {
      return reply(m,
`🎵 *${config.botName || 'BOT'} - YOUTUBE PLAY*

📌 *Cara Pakai:*
> \`${usedPrefix}${command} <judul lagu / link youtube>\`

💡 *Contoh:*
> \`${usedPrefix}${command} Never Gonna Give You Up\`
> \`${usedPrefix}${command} https://youtu.be/dQw4w9WgXcQ\``);
    }

    if (!API_KEY) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    /* ============ MODE 1: LINK YOUTUBE ============ */
    if (text.includes('youtube.com') || text.includes('youtu.be')) {
      console.log("[play] download mode, url:", text);
      const audioData = await getYouTubeAudio(text.trim());

      await conn.sendMessage(m.chat, { react: { text: "📥", key: m.key } });

      const audioRes = await axios.get(audioData.downloadUrl, {
        responseType: 'arraybuffer',
        timeout: 120000,
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
      });

      const audioBuffer = Buffer.from(audioRes.data);
      const safeTitle = String(audioData.title || 'audio').replace(/[\\/:*?"<>|]/g, '').trim() || 'audio';
      const filename = `${safeTitle}.mp3`;
      const caption =
        `🎵 *${config.botName || 'BOT'}*\n\n` +
        `📌 *Judul:* ${audioData.title}\n` +
        `👤 *Channel:* ${audioData.author}\n` +
        `⏱️ *Durasi:* ${audioData.duration}\n` +
        `✨ *Request by:* ${m.pushName || 'User'}`;
      const sizeMB = (audioBuffer.length / (1024 * 1024)).toFixed(1);

      let sent = false;

      if (audioBuffer.length <= 20 * 1024 * 1024) {
        try {
          await conn.sendMessage(m.chat, {
            audio: audioBuffer, mimetype: 'audio/mpeg', ptt: false, fileName: filename
          }, { quoted: m.raw });
          sent = true;
        } catch (errAudio) {
          console.warn('[PLAY] Gagal kirim audio:', errAudio.message);
        }
      }

      if (!sent && audioBuffer.length <= 100 * 1024 * 1024) {
        try {
          await conn.sendMessage(m.chat, {
            document: audioBuffer, mimetype: 'audio/mpeg', fileName: filename, caption
          }, { quoted: m.raw });
          sent = true;
        } catch (errDoc) {
          console.warn('[PLAY] Gagal kirim dokumen:', errDoc.message);
        }
      }

      if (!sent) {
        await conn.sendMessage(m.chat, {
          text: `${caption}\n\n⚠️ Audio (${sizeMB} MB) terlalu besar.\n📥 Link: ${audioData.downloadUrl}`
        }, { quoted: m.raw });
      }

      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return;
    }

    /* ============ MODE 2: KATA KUNCI ============ */
    const videos = await searchYoutube(text.trim());
    if (!videos.length) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, `❌ Tidak ditemukan lagu untuk: "${text}"`);
    }

    await sendPickerList(sock, m, videos, text);
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error('[play] Error:', error);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    reply(m, `❌ *Gagal:* ${error.message}`);
  }
}

export default {
  handle,
  Commands: ["play", "musik", "music", "song"],
  OnlyPremium: false,
  OnlyOwner: false
};