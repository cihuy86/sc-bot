'use strict';

import { downloadContentFromMessage } from "@sairidev/baileys-new";
import config from "../../config.js";
import { getCachedViewOnce, getCachedByChat } from "../../lib/viewOnceCache.js";

/* ============ WRAPPER VIEW ONCE ============ */
const VIEW_ONCE_WRAPPERS = [
  "viewOnceMessageV2",
  "viewOnceMessageV2Extension",
  "viewOnceMessage"
];

/* ============ EXTRACT MEDIA (RECURSIVE) ============ */
function extractMedia(message, depth = 0) {
  if (!message || depth > 5) return null;

  if (message.imageMessage) return { type: "image", media: message.imageMessage };
  if (message.videoMessage) return { type: "video", media: message.videoMessage };
  if (message.audioMessage) return { type: "audio", media: message.audioMessage };

  for (const w of VIEW_ONCE_WRAPPERS) {
    if (message[w]?.message) {
      const found = extractMedia(message[w].message, depth + 1);
      if (found) return found;
    }
  }

  if (message.documentWithCaptionMessage?.message) {
    const found = extractMedia(message.documentWithCaptionMessage.message, depth + 1);
    if (found) return found;
  }

  return null;
}

/* ============ AMBIL MEDIA DARI PESAN ============ */
function getViewOnceMedia(m) {
  const direct = extractMedia(m.message);
  if (direct) {
    console.log("[rvo] media ditemukan di pesan langsung");
    return { source: "direct", ...direct };
  }

  const msg = m.message || {};
  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.audioMessage?.contextInfo ||
    msg.documentMessage?.contextInfo ||
    msg.stickerMessage?.contextInfo;

  if (ctx?.quotedMessage) {
    const fromQuoted = extractMedia(ctx.quotedMessage);
    if (fromQuoted) {
      console.log("[rvo] media ditemukan di quoted");
      return { source: "quoted", ...fromQuoted };
    }

    const quotedId = ctx.stanzaId;
    if (quotedId) {
      console.log("[rvo] cek cache untuk quotedId:", quotedId);
      const cached = getCachedViewOnce(quotedId);
      if (cached) {
        console.log("[rvo] ✅ media ditemukan di cache");
        return {
          source: "cache",
          type: cached.mediaType,
          media: cached.mediaObj
        };
      }
    }

    const sender = ctx.participant || msg.extendedTextMessage?.contextInfo?.participant;
    console.log("[rvo] cache by chat fallback, sender:", sender);
    const cachedFallback = getCachedByChat(m.chat, sender);
    if (cachedFallback) {
      console.log("[rvo] ✅ media ditemukan di cache (fallback)");
      return {
        source: "cache-fallback",
        type: cachedFallback.mediaType,
        media: cachedFallback.mediaObj
      };
    }
  }

  return null;
}

/* ============ DOWNLOAD MEDIA ============ */
async function downloadMedia(mediaObj, type) {
  if (!mediaObj.mediaKey && !mediaObj.directPath) {
    throw new Error("Media key kosong — pesan mungkin sudah expired");
  }

  const stream = await downloadContentFromMessage(mediaObj, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

/* ============================================================ */
/* ============ HANDLER ============ */
/* ============================================================ */
async function handle(sock, messageInfo) {
  const { m } = messageInfo;
  const prefix = config.prefix || ".";

  const found = getViewOnceMedia(m);

  if (!found) {
    return m.reply(
      `⚠️ *Format salah.*\n\n` +
      `*Cara pakai:*\n` +
      `Reply pesan *view once* → ketik \`${prefix}rvo\`\n\n` +
      `💡 Bot auto-save view once pas masuk chat, jadi bisa di-RVO walau udah dibuka.`
    );
  }

  await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
    const buffer = await downloadMedia(found.media, found.type);

    if (!buffer || buffer.length === 0) {
      throw new Error("Media kosong / gagal didownload");
    }

    const caption = found.media.caption || "";
    const mimetype = found.media.mimetype || "";

    console.log(`[rvo] ${found.type} | ${(buffer.length / 1024).toFixed(1)} KB | source: ${found.source}`);

    if (found.type === "image") {
      await sock.sendMessage(
        m.chat,
        { image: buffer, caption, mimetype: mimetype || "image/jpeg" },
        { quoted: m.raw }
      );
    } else if (found.type === "video") {
      await sock.sendMessage(
        m.chat,
        { video: buffer, caption, mimetype: mimetype || "video/mp4" },
        { quoted: m.raw }
      );
    } else if (found.type === "audio") {
      await sock.sendMessage(
        m.chat,
        {
          audio: buffer,
          mimetype: mimetype || "audio/ogg; codecs=opus",
          ptt: found.media.ptt === true
        },
        { quoted: m.raw }
      );
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
    console.error("[rvo] error:", e);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    return m.reply(`❌ Gagal: ${e.message}`);
  }
}

export default {
  handle,
  Commands: ["rvo", "readviewonce", "r"],
  OnlyPremium: false,
  OnlyOwner: false
};