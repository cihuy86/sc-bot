'use strict';

import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  if (!text) {
    return reply(m,
`*Format salah!*

📌 *Contoh:*
\`${usedPrefix}${command} https://pin.it/xxxx\``);
  }

  const input = text.trim();

  // kalau bukan URL, kasih saran pakai .pin
  if (!input.startsWith('http://') && !input.startsWith('https://')) {
    return reply(m,
`⚠️ Command *${usedPrefix}${command}* khusus untuk mendownload dari link/URL Pinterest.

Untuk mencari foto/gambar, gunakan:
*${usedPrefix}pin ${input}*`);
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});

  try {
    const apiKey = getActiveKey();
    if (!apiKey) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    const url = `${JEREXD_BASE}/api/downloader/pin?apikey=${apiKey}&url=${encodeURIComponent(input)}`;
    console.log("[pinterest] calling:", url.slice(0, 150));

    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
      signal: AbortSignal.timeout(60000)
    });

    const json = await res.json();
    console.log("[pinterest] response:", JSON.stringify(json).slice(0, 400));

    if (!json.status || !json.result) {
      throw new Error(json.error || json.message || 'Gagal memproses tautan Pinterest');
    }

    const resData = json.result;
    const mediaUrl =
      resData.url ||
      resData.download_url ||
      resData.image ||
      resData.video ||
      (typeof resData === 'string' ? resData : null);

    if (!mediaUrl) throw new Error('Link media Pinterest tidak ditemukan');

    const isVideo = resData.type === 'video' || /\.(mp4|mov|avi)($|\?)/i.test(mediaUrl);

    const caption = `📌 *${config.botName || 'BOT'} - PINTEREST DOWNLOADER*\n\n` +
      `✨ *Request by:* ${m.pushName || 'User'}`;

    if (isVideo) {
      await conn.sendMessage(m.chat, {
        video: { url: mediaUrl },
        caption: caption,
        fileName: `pinterest_${Date.now()}.mp4`
      }, { quoted: m.raw });
    } else {
      await conn.sendMessage(m.chat, {
        image: { url: mediaUrl },
        caption: caption
      }, { quoted: m.raw });
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});

  } catch (e) {
    console.error("[pinterest]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
    reply(m, `❌ *Error:* ${e.message || 'Terjadi kesalahan pada server'}`);
  }
}

export default {
  handle,
  Commands: ["pindl", "pinterestdl", "pinvid", "pindownload", "pindownloader"],
  OnlyPremium: false,
  OnlyOwner: false
};