'use strict';

import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  /* ============ CEK INPUT ============ */
  if (!text) {
    return reply(m,
`🔓 *SFL.GL BYPASS*

Lewati tautan Safelink sfl.gl / sfile!

*Contoh:*
• \`${usedPrefix}${command} https://sfl.gl/xxxx\`
• \`${usedPrefix}${command} https://sfile.mobi/xxxx\``);
  }

  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const url = text.trim();
    const apiKey = getActiveKey();

    if (!apiKey) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    const apiUrl = `${JEREXD_BASE}/api/tools/bypas-sfl?apikey=${apiKey}`;

    const res = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });

    const json = await res.json();
    console.log("[sfl] response:", JSON.stringify(json).slice(0, 300));

    if (!json.status) {
      throw new Error(json.error || json.detail || json.message || "Gagal membypass link sfl.");
    }

    const data = json.result || {};

    let caption = `🔓 *SFL BYPASS BERHASIL*\n\n`;
    caption += `🔗 *Link Asal:*\n${data.original_url || url}\n\n`;
    caption += `🎯 *Link Tujuan:*\n${data.bypassed_url || "-"}\n\n`;
    caption += `⏱️ *Waktu Proses:* ${json.time_taken || data.time_taken || "-"}s\n\n`;
    caption += `✅ *Request by:* ${m.pushName || "User"}`;

    await reply(m, caption);
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (e) {
    console.error("[sfl]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    reply(m, `❌ *Bypass SFL Gagal*\nError: ${e.message}`);
  }
}

export default {
  handle,
  Commands: ["bypas-sfl", "bypasssfl", "sflbypass"],
  OnlyPremium: false,
  OnlyOwner: false
};