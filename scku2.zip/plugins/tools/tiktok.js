'use strict';

import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (args || []).join(" ").trim();

  if (!text) {
    return reply(m,
`*Format salah!*

📌 *Contoh:*
\`${usedPrefix}${command} https://vt.tiktok.com/xxxx\``);
  }

  // react loading
  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});

  try {
    const apiKey = getActiveKey();
    if (!apiKey) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    const url = `${JEREXD_BASE}/api/downloader/tiktok?apikey=${apiKey}&url=${encodeURIComponent(text.trim())}`;
    console.log("[tiktok] calling:", url.slice(0, 150));

    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
      signal: AbortSignal.timeout(60000)
    });

    const json = await res.json();
    console.log("[tiktok] response:", JSON.stringify(json).slice(0, 400));

    if (!json.status) {
      throw new Error(json.error || json.detail || json.message || 'Gagal memproses video TikTok');
    }

    const raw = json.raw_data || json.data || {};
    const title = json.description || raw.title || '-';
    const author = raw.author?.nickname || raw.nickname || '-';
    const username = raw.author?.unique_id || raw.unique_id || '-';
    const duration = raw.duration ? `${raw.duration} detik` : '-';
    const views = raw.play_count ? raw.play_count.toLocaleString() : '-';
    const likes = raw.digg_count ? raw.digg_count.toLocaleString() : '-';
    const comments = raw.comment_count ? raw.comment_count.toLocaleString() : '-';
    const shares = raw.share_count ? raw.share_count.toLocaleString() : '-';
    const musicTitle = raw.music_info?.title || raw.music || '-';

    const caption = `🎵 *${config.botName || 'BOT'} - TIKTOK DOWNLOADER*\n\n` +
      `📌 *Judul:* ${title}\n` +
      `👤 *Author:* ${author} (@${username})\n` +
      `⏱️ *Durasi:* ${duration}\n` +
      `👁️ *Views:* ${views} | ❤️ *Likes:* ${likes}\n` +
      `💬 *Komentar:* ${comments} | 🔁 *Shares:* ${shares}\n` +
      `🎶 *Musik:* ${musicTitle}\n` +
      `✨ *Request by:* ${m.pushName || 'User'}`;

    /* ============ PHOTO SLIDE / IMAGES ============ */
    const images = raw.images || json.images || json.data?.images || json.result?.images;

    if (images && Array.isArray(images) && images.length > 0) {
      await reply(m, `📸 Menemukan *${images.length}* foto slide, sedang mengirim...`);

      for (let i = 0; i < images.length; i++) {
        const imgUrl = typeof images[i] === 'string' ? images[i] : images[i].url;
        if (imgUrl) {
          await conn.sendMessage(m.chat, {
            image: { url: imgUrl },
            caption: `📸 *Slide ${i + 1}/${images.length}*\n📝 ${title}`
          }, { quoted: m.raw });
        }
      }

      const audioUrl =
        json.links?.find(l => l.label?.toLowerCase().includes('audio') || l.label?.toLowerCase().includes('mp3'))?.url ||
        raw.music ||
        raw.music_info?.play_url;

      if (audioUrl) {
        await conn.sendMessage(m.chat, {
          audio: { url: audioUrl },
          mimetype: 'audio/mpeg',
          fileName: `${title.slice(0, 30) || 'tiktok_audio'}.mp3`
        }, { quoted: m.raw }).catch(() => {});
      }

      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});
      return;
    }

    /* ============ VIDEO ============ */
    const videoUrl =
      json.links?.find(l => l.label?.toLowerCase().includes('without') || l.label?.toLowerCase().includes('nowm'))?.url ||
      raw.play ||
      json.links?.[0]?.url ||
      json.data?.play ||
      json.result?.play;

    if (!videoUrl) throw new Error('Link video TikTok tidak ditemukan');

    await conn.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: caption,
      fileName: `tiktok_${Date.now()}.mp4`
    }, { quoted: m.raw });

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});

  } catch (e) {
    console.error("[tiktok]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
    reply(m, `❌ *Error:* ${e.message || 'Terjadi kesalahan pada server'}`);
  }
}

export default {
  handle,
  Commands: ["tiktok", "tiktokdl", "tt"],
  OnlyPremium: false,
  OnlyOwner: false
};