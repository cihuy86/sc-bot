'use strict';

import axios from 'axios';
import { downloadContentFromMessage } from "@sairidev/baileys-new";
import { reply } from "../../lib/utils.js";
import { getActiveKey } from "../../lib/apikeys.js";
import { sticker } from "../../lib/sticker.js";
import { uploader as uploadImage } from "../../lib/uploadImage.js";
import config from "../../config.js";

const JEREXD_BASE = "https://api.jerexd.my.id";

/* ============ AMBIL GAMBAR DARI PESAN ============ */
function getImageFromMessage(m) {
  const msg = m.message || {};
  if (msg.imageMessage) return { media: msg.imageMessage, mime: msg.imageMessage.mimetype };

  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.documentMessage?.contextInfo;

  if (ctx?.quotedMessage?.imageMessage) {
    return { media: ctx.quotedMessage.imageMessage, mime: ctx.quotedMessage.imageMessage.mimetype };
  }
  return null;
}

async function downloadMedia(mediaObj, type) {
  const stream = await downloadContentFromMessage(mediaObj, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";

  try {
    const text = (args || []).join(" ").trim();

    if (!text) {
      return reply(m, `⚠️ Masukkan teks atas dan bawah dipisah dengan '|'\n\nContoh:\n\`${usedPrefix}${command} atas | bawah\``);
    }

    let [atas, bawah] = text.split('|').map(v => v.trim());

    if (!bawah) {
      bawah = atas;
      atas = "_";
    }

    const found = getImageFromMessage(m);
    const mime = found?.mime || "";

    if (!found || !/image/.test(mime)) {
      return reply(m, `⚠️ Reply gambar dengan caption \`${usedPrefix}${command} <teks atas> | <teks bawah>\``);
    }

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const media = await downloadMedia(found.media, "image");

    if (!media || media.length === 0) {
      throw new Error("Gagal download gambar");
    }

    /* ============ UPLOAD GAMBAR ============ */
    let imgUrl;
    try {
      imgUrl = await uploadImage(media);
    } catch (e) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, `❌ Gagal upload gambar: ${e.message}`);
    }

    /* ============ CALL API ============ */
    const apiKey = getActiveKey();
    if (!apiKey) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m, "⚠️ Belum ada API key aktif. Set dulu pakai `.apikey add <key>`");
    }

    const url = `${JEREXD_BASE}/api/maker/smeme`;
    console.log("[smeme] calling:", url);

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        apikey: apiKey,
        atas: atas,
        bawah: bawah,
        url: imgUrl
      }),
      signal: AbortSignal.timeout(60000)
    });

    if (!response.ok) {
      throw new Error(`Gagal membuat sticker meme (HTTP ${response.status})`);
    }

    const resultBuffer = Buffer.from(await response.arrayBuffer());

    if (!resultBuffer || resultBuffer.length < 100) {
      throw new Error("Response kosong / korup");
    }

    /* ============ BUILD STICKER ============ */
    const packname = config.packname || "SIX CORE";
    const author = config.author || "Bot";
    const stiker = await sticker(resultBuffer, false, packname, author);

    /* ============ KIRIM ============ */
    await conn.sendMessage(m.chat, {
      sticker: stiker
    }, { quoted: m.raw });

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (e) {
    console.error("[smeme]", e);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    reply(m, "❌ Error: " + e.message);
  }
}

export default {
  handle,
  Commands: ["smeme", "stickermeme"],
  OnlyPremium: false,
  OnlyOwner: false
};