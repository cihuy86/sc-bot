'use strict';

import { reply, isOwner } from "../../lib/utils.js";
import {
  listKeys,
  addKey,
  delKey,
  setActive,
  editLabel,
  clearAll,
  maskKey
} from "../../lib/apikeys.js";
import config from "../../config.js";

async function handle(sock, messageInfo) {
  const { m, args } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) return reply(m, "🔒 _Command ini khusus owner._");

  const sub = (args[0] || "").toLowerCase();
  const rest = args.slice(1).join(" ").trim();

  /* ============ DEFAULT: LIST ============ */
  if (!sub || sub === "list") {
    const data = listKeys();

    if (!data.keys.length) {
      return reply(m,
`🔑 *MANAGEMENT API KEY*

Belum ada API key tersimpan.

*Cara pakai:*
• \`${prefix}apikey add <key> [label]\`
• \`${prefix}apikey del <nomor/key/label>\`
• \`${prefix}apikey use <nomor/key/label>\`
• \`${prefix}apikey label <nomor> <label baru>\`
• \`${prefix}apikey clear\``);
    }

    let out = `🔑 *DAFTAR API KEY*\n\n`;
    data.keys.forEach((k, i) => {
      const isActive = k.key === data.active;
      const marker = isActive ? " ✅" : "";
      const label = k.label || `Key ${i + 1}`;
      out += `*${i + 1}.*${marker} ${label}\n`;
      out += `    🔑 \`${maskKey(k.key)}\`\n\n`;
    });
    out += `━━━━━━━━━━━━━━━━━━━━\n`;
    out += `Total: *${data.keys.length}* key\n`;
    out += `Aktif: \`${maskKey(data.active)}\`\n\n`;
    out += `*Command:*\n`;
    out += `• \`${prefix}apikey add <key> [label]\`\n`;
    out += `• \`${prefix}apikey del <nomor/key/label>\`\n`;
    out += `• \`${prefix}apikey use <nomor/key/label>\`\n`;
    out += `• \`${prefix}apikey label <nomor> <label baru>\`\n`;
    out += `• \`${prefix}apikey clear\``;

    return reply(m, out);
  }

  /* ============ ADD ============ */
  if (sub === "add" || sub === "tambah") {
    if (!rest) {
      return reply(m,
`⚠️ Format: \`${prefix}apikey add <key> [label]\`

Contoh:
• \`${prefix}apikey add jere_xxx123\`
• \`${prefix}apikey add jere_xxx123 Jerexd Main\``);
    }

    const parts = rest.split(/\s+/);
    const key = parts[0];
    const label = parts.slice(1).join(" ") || "";

    const res = addKey(key, label);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *API Key ditambahkan!*

🔑 \`${maskKey(key)}\`
📝 Label: ${label || `Key ${res.total}`}
📊 Total: ${res.total} key`);
  }

  /* ============ DELETE ============ */
  if (sub === "del" || sub === "delete" || sub === "hapus" || sub === "remove") {
    if (!rest) {
      return reply(m, `⚠️ Format: \`${prefix}apikey del <nomor/key/label>\`\n\nContoh:\n• \`${prefix}apikey del 2\`\n• \`${prefix}apikey del Jerexd Utama\``);
    }

    const res = delKey(rest);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *API Key dihapus!*

🔑 \`${maskKey(res.removed.key)}\`
📝 Label: ${res.removed.label || "-"}
📊 Sisa: ${res.total} key`);
  }

  /* ============ USE ============ */
  if (sub === "use" || sub === "set" || sub === "aktif" || sub === "active") {
    if (!rest) {
      return reply(m, `⚠️ Format: \`${prefix}apikey use <nomor/key/label>\`\n\nContoh:\n• \`${prefix}apikey use 2\`\n• \`${prefix}apikey use Jerexd Utama\``);
    }

    const res = setActive(rest);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *API Key aktif diganti!*

🔑 \`${maskKey(res.active)}\`
📝 Label: ${res.label}`);
  }

  /* ============ EDIT LABEL ============ */
  if (sub === "label" || sub === "rename") {
    if (args.length < 3) {
      return reply(m,
`⚠️ Format: \`${prefix}apikey label <nomor> <label baru>\`

Contoh:
• \`${prefix}apikey label 1 Jerexd Backup\`
• \`${prefix}apikey label 2 API Cadangan\``);
    }

    const target = args[1];
    const newLabel = args.slice(2).join(" ").trim();

    const res = editLabel(target, newLabel);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *Label diubah!*

🔑 \`${maskKey(res.key)}\`
📝 Label lama: ${res.oldLabel}
📝 Label baru: ${res.newLabel}`);
  }

  /* ============ CLEAR ============ */
  if (sub === "clear" || sub === "reset") {
    clearAll();
    return reply(m, "✅ Semua API key berhasil dihapus.");
  }

  /* ============ HELP ============ */
  return reply(m,
`⚠️ Sub-command tidak dikenal.

*Yang tersedia:*
• \`${prefix}apikey\` — lihat daftar
• \`${prefix}apikey add <key> [label]\` — tambah
• \`${prefix}apikey del <nomor/key/label>\` — hapus
• \`${prefix}apikey use <nomor/key/label>\` — aktifkan
• \`${prefix}apikey label <nomor> <label baru>\` — edit label
• \`${prefix}apikey clear\` — hapus semua`);
}

export default {
  handle,
  Commands: ["apikey", "apikeys", "key"],
  OnlyOwner: true
};