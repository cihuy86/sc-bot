'use strict';

import * as baileys from "@sairidev/baileys-new";
import {
  generateWAMessageContent,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  proto
} from "@sairidev/baileys-new";
import crypto from "node:crypto";
import { PassThrough } from "stream";
import ffmpeg from "fluent-ffmpeg";
import ffmpegPath from "@ffmpeg-installer/ffmpeg";
import fs from "fs";
import path from "path";
import config from "../../config.js";
import { isOwner } from "../../lib/utils.js";

ffmpeg.setFfmpegPath(ffmpegPath.path);

/* ============ AMBIL MEDIA ============ */
function getMedia(m) {
  const msg = m.message || {};
  if (msg.imageMessage) return { media: msg.imageMessage, type: "image", mime: msg.imageMessage.mimetype };
  if (msg.videoMessage) return { media: msg.videoMessage, type: "video", mime: msg.videoMessage.mimetype, duration: msg.videoMessage.seconds };
  if (msg.audioMessage) return { media: msg.audioMessage, type: "audio", mime: msg.audioMessage.mimetype };

  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.audioMessage?.contextInfo ||
    msg.documentMessage?.contextInfo;

  if (ctx?.quotedMessage) {
    const q = ctx.quotedMessage;
    if (q.imageMessage) return { media: q.imageMessage, type: "image", mime: q.imageMessage.mimetype };
    if (q.videoMessage) return { media: q.videoMessage, type: "video", mime: q.videoMessage.mimetype, duration: q.videoMessage.seconds };
    if (q.audioMessage) return { media: q.audioMessage, type: "audio", mime: q.audioMessage.mimetype };
  }
  return null;
}

async function downloadMedia(mediaObj, type) {
  const stream = await downloadContentFromMessage(mediaObj, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

/* ============ SPLIT VIDEO ============ */
async function splitVideoIntoSegments(videoBuffer, durationInSeconds, m, conn) {
  const segments = [];
  const maxSegmentDuration = 60;
  const totalSegments = Math.ceil(durationInSeconds / maxSegmentDuration);
  const tempDir = path.join(process.cwd(), 'temp');
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

  const inputPath = path.join(tempDir, `video_input_${Date.now()}.mp4`);
  fs.writeFileSync(inputPath, videoBuffer);

  for (let i = 0; i < totalSegments; i++) {
    await conn.sendMessage(m.chat, { react: { text: "✂️", key: m.key } });
    const startTime = i * maxSegmentDuration;
    const remainingDuration = durationInSeconds - startTime;
    const segmentDuration = Math.min(maxSegmentDuration, remainingDuration);
    const outputPath = path.join(tempDir, `video_segment_${Date.now()}_${i + 1}.mp4`);

    await new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .setStartTime(startTime)
        .setDuration(segmentDuration)
        .output(outputPath)
        .on('end', () => resolve())
        .on('error', (err) => reject(err))
        .run();
    });

    const segmentBuffer = fs.readFileSync(outputPath);
    segments.push({ buffer: segmentBuffer, index: i + 1, total: totalSegments });
    fs.unlinkSync(outputPath);
  }
  fs.unlinkSync(inputPath);
  return segments;
}

/* ============ GROUP STATUS ============ */
async function groupStatus(conn, jid, content) {
  console.log("\n========== [swgc] START groupStatus ==========");
  console.log("[swgc] jid:", jid);

  console.log("[swgc] proto.Message.GroupStatusMessageV2:", typeof proto?.Message?.GroupStatusMessageV2);
  console.log("[swgc] proto.Message.GroupStatusMessage:", typeof proto?.Message?.GroupStatusMessage);

  /* ===== UPLOAD MEDIA ===== */
  let mediaMessage = null;

  if (content.image) {
    const media = await prepareWAMessageMedia(
      { image: content.image, caption: content.caption || "" },
      { upload: conn.waUploadToServer }
    );
    mediaMessage = { imageMessage: media.imageMessage };
    console.log("[swgc] ✅ image uploaded");
  } else if (content.video) {
    const media = await prepareWAMessageMedia(
      { video: content.video, caption: content.caption || "" },
      { upload: conn.waUploadToServer }
    );
    mediaMessage = { videoMessage: media.videoMessage };
    console.log("[swgc] ✅ video uploaded");
  } else if (content.audio) {
    const media = await prepareWAMessageMedia(
      { audio: content.audio, ptt: true, mimetype: "audio/ogg; codecs=opus" },
      { upload: conn.waUploadToServer }
    );
    mediaMessage = {
      audioMessage: { ...media.audioMessage, ptt: true, waveform: content.waveform }
    };
  } else if (content.text) {
    mediaMessage = {
      extendedTextMessage: {
        text: content.text,
        backgroundArgb: content.backgroundColor ? parseInt(content.backgroundColor.replace("#", ""), 16) : 0xFF25D366
      }
    };
  }

  const messageSecret = crypto.randomBytes(32);

  /* ===== BUILD MESSAGE ===== */
  let msgContent = null;

  if (proto?.Message?.GroupStatusMessageV2) {
    try {
      console.log("[swgc] coba proto v2");
      msgContent = {
        messageContextInfo: proto.MessageContextInfo.fromObject({ messageSecret }),
        groupStatusMessageV2: proto.Message.GroupStatusMessageV2.fromObject({
          message: {
            ...mediaMessage,
            messageContextInfo: { messageSecret }
          }
        })
      };
    } catch (e) {
      console.log("[swgc] gagal proto v2:", e.message);
    }
  }

  if (!msgContent && proto?.Message?.GroupStatusMessage) {
    try {
      console.log("[swgc] coba proto v1");
      msgContent = {
        messageContextInfo: proto.MessageContextInfo.fromObject({ messageSecret }),
        groupStatusMessage: proto.Message.GroupStatusMessage.fromObject({
          message: mediaMessage
        })
      };
    } catch (e) {
      console.log("[swgc] gagal proto v1:", e.message);
    }
  }

  if (!msgContent) {
    console.log("[swgc] fallback plain object");
    msgContent = {
      messageContextInfo: { messageSecret },
      groupStatusMessageV2: {
        message: {
          ...mediaMessage,
          messageContextInfo: { messageSecret }
        }
      }
    };
  }

  console.log("[swgc] msgContent keys:", Object.keys(msgContent));

  const finalMsg = generateWAMessageFromContent(jid, msgContent, {});
  console.log("[swgc] finalMsg.message keys:", Object.keys(finalMsg.message));

  /* ===== RELAY ===== */
  console.log("[swgc] relaying...");
  const startTime = Date.now();

  try {
    await Promise.race([
      conn.relayMessage(jid, finalMsg.message, { messageId: finalMsg.key.id }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("timeout 20s")), 20000))
    ]);
    console.log(`[swgc] ✅ relay sukses (${Date.now() - startTime}ms)`);
  } catch (e) {
    console.log(`[swgc] ❌ relay gagal (${Date.now() - startTime}ms):`, e.message);
    throw e;
  }

  return finalMsg;
}

/* ============ TO VN ============ */
async function toVN(inputBuffer) {
  return new Promise((resolve, reject) => {
    const inStream = new PassThrough();
    const outStream = new PassThrough();
    const chunks = [];
    inStream.end(inputBuffer);

    ffmpeg(inStream)
      .noVideo().audioCodec('libopus').format('ogg')
      .audioBitrate('48k').audioChannels(1).audioFrequency(48000)
      .outputOptions(['-map_metadata', '-1', '-application', 'voip', '-compression_level', '10', '-page_duration', '20000'])
      .on('error', reject)
      .on('end', () => resolve(Buffer.concat(chunks)))
      .pipe(outStream, { end: true });

    outStream.on('data', c => chunks.push(c));
  });
}

/* ============ WAVEFORM ============ */
async function generateWaveform(inputBuffer, bars = 64) {
  return new Promise((resolve, reject) => {
    const inputStream = new PassThrough();
    inputStream.end(inputBuffer);
    const chunks = [];

    ffmpeg(inputStream)
      .audioChannels(1).audioFrequency(16000).format("s16le")
      .on("error", reject)
      .on("end", () => {
        const rawData = Buffer.concat(chunks);
        const samples = rawData.length / 2;
        const amplitudes = [];
        for (let i = 0; i < samples; i++) {
          amplitudes.push(Math.abs(rawData.readInt16LE(i * 2)) / 32768);
        }
        let blockSize = Math.floor(amplitudes.length / bars);
        let avg = [];
        for (let i = 0; i < bars; i++) {
          let block = amplitudes.slice(i * blockSize, (i + 1) * blockSize);
          avg.push(block.reduce((a, b) => a + b, 0) / block.length);
        }
        let max = Math.max(...avg);
        let normalized = avg.map(v => Math.floor((v / max) * 100));
        resolve(Buffer.from(new Uint8Array(normalized)).toString("base64"));
      })
      .pipe()
      .on("data", chunk => chunks.push(chunk));
  });
}

/* ============================================================ */
/* ============ HANDLER ============ */
/* ============================================================ */
let handler = async (sock, messageInfo) => {
  const { m, args: argArr, command } = messageInfo;
  const conn = sock;
  const usedPrefix = config.prefix || ".";
  const text = (argArr || []).join(" ").trim();
  const isOwnerCtx = isOwner(m);

  try {
    if (!isOwnerCtx) {
      return m.reply('Akses ditolak! Owner only.');
    }

    console.log("\n========== [swgc] COMMAND:", command, "==========");

    let args = (text || '').split('|').map(v => v.trim()).filter(v => v);
    let caption = '';
    let warna = '';
    let targetGroup = m.chat;

    for (let v of args) {
      if (/chat\.whatsapp\.com\//.test(v)) {
        try {
          const inviteCode = v.split('/').pop().split('?')[0];
          const inviteInfo = await conn.groupGetInviteInfo(inviteCode);
          targetGroup = inviteInfo.id;
          console.log("[swgc] target group dari link:", targetGroup);
        } catch {
          return m.reply('Link grup tidak valid');
        }
      } else if (!caption) {
        caption = v;
      } else if (!warna) {
        warna = v;
      }
    }

    console.log("[swgc] target group:", targetGroup);

    const media = getMedia(m);
    const warnaMap = {
      'biru': '#34B7F1', 'hijau': '#25D366', 'kuning': '#FFD700',
      'jingga': '#FF8C00', 'merah': '#FF3B30', 'ungu': '#9C27B0',
      'abu': '#9E9E9E', 'hitam': '#000000', 'putih': '#FFFFFF', 'cyan': '#00BCD4'
    };

    if (media && media.type === "image") {
      console.log("[swgc] mode: IMAGE");
      const buffer = await downloadMedia(media.media, "image");
      console.log("[swgc] image size:", buffer.length);
      await groupStatus(conn, targetGroup, { image: buffer, caption: caption || '' });
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return m.reply(`✅ Story gambar berhasil dikirim!`);
    }

    if (media && media.type === "video") {
      console.log("[swgc] mode: VIDEO");
      const duration = media.duration || 0;
      const buffer = await downloadMedia(media.media, "video");

      if (duration <= 60) {
        await groupStatus(conn, targetGroup, { video: buffer, caption: caption || '' });
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        return m.reply(`✅ Story video berhasil dikirim!`);
      }

      const segments = await splitVideoIntoSegments(buffer, duration, m, conn);
      for (const seg of segments) {
        await groupStatus(conn, targetGroup, { video: seg.buffer, caption: '' });
        await new Promise(r => setTimeout(r, 1000));
      }
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return m.reply(`✅ Story video terkirim (${segments.length} bagian)`);
    }

    if (media && media.type === "audio") {
      const buffer = await downloadMedia(media.media, "audio");
      const audioVn = await toVN(buffer);
      const audioWaveform = await generateWaveform(buffer);
      await groupStatus(conn, targetGroup, {
        audio: audioVn, waveform: audioWaveform,
        mimetype: "audio/ogg; codecs=opus", ptt: true
      });
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return m.reply(`✅ Story audio terkirim!`);
    }

    if (caption && warna) {
      const color = warnaMap[warna.toLowerCase()];
      if (!color) return m.reply(`Warna tidak dikenal. Tersedia: ${Object.keys(warnaMap).join(', ')}`);
      await groupStatus(conn, targetGroup, { text: caption, backgroundColor: color });
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return m.reply(`✅ Story teks terkirim!`);
    }

    if (caption) {
      await groupStatus(conn, targetGroup, { text: caption, backgroundColor: '#25D366' });
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      return m.reply(`✅ Story teks terkirim!`);
    }

    return m.reply(`Format: ${usedPrefix}${command} (reply media) atau ${usedPrefix}${command} <teks>`);
  } catch (e) {
    console.error("[swgc] FATAL:", e);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply(`❌ Error: ${e.message}`);
  }
};

export default {
  handle: handler,
  Commands: ["swgc", "upswgc", "swgcall", "swgcbc", "groupstoryall"],
  OnlyPremium: false,
  OnlyOwner: true
};