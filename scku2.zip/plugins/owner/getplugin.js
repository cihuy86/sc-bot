'use strict';

import fs from 'fs';
import path from 'path';
import { reply, isOwner } from "../../lib/utils.js";
import { plugins, pluginList } from "../../lib/pluginHandler.js";
import config from "../../config.js";

/* ============ CARI PLUGIN BY NAMA ============ */
function findPlugin(query) {
  const q = String(query).toLowerCase().trim();

  // 1. coba by command name
  const byCommand = plugins.get(q);
  if (byCommand) {
    return {
      file: byCommand.file,
      primary: byCommand.primary,
      category: byCommand.category,
      commands: byCommand.commands
    };
  }

  // 2. coba by filename
  const byFile = pluginList.find(p => {
    const filename = path.basename(p.file, ".js").toLowerCase();
    return filename === q;
  });
  if (byFile) {
    return {
      file: byFile.file,
      primary: byFile.primary,
      category: byFile.category,
      commands: byFile.commands
    };
  }

  // 3. coba by partial match (folder/nama)
  const byPartial = pluginList.find(p => {
    const normalized = p.file.replace(/\\/g, "/").toLowerCase();
    return normalized.includes(q);
  });
  if (byPartial) {
    return {
      file: byPartial.file,
      primary: byPartial.primary,
      category: byPartial.category,
      commands: byPartial.commands
    };
  }

  return null;
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) return reply(m, "🔒 _Command ini khusus owner._");

  const query = (args || []).join(" ").trim();

  if (!query) {
    // tampilkan list plugin
    let out = `📦 *GET PLUGIN*\n\n`;
    out += `*Cara pakai:*\n`;
    out += `• \`${prefix}${command} <nama plugin>\`\n`;
    out += `• \`${prefix}${command} <nama file>\`\n`;
    out += `• \`${prefix}${command} <folder/nama>\`\n\n`;

    out += `*Contoh:*\n`;
    out += `• \`${prefix}${command} dino\`\n`;
    out += `• \`${prefix}${command} ytsearch\`\n`;
    out += `• \`${prefix}${command} game/catur\`\n\n`;

    out += `📋 *Total plugin:* ${pluginList.length}\n\n`;

    // group by category
    const grouped = {};
    for (const p of pluginList) {
      const cat = p.category || "other";
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(p.primary);
    }

    for (const cat of Object.keys(grouped).sort()) {
      out += `📁 *${cat}*\n`;
      for (const cmd of grouped[cat]) {
        out += `  ◦ ${config.prefix}${cmd}\n`;
      }
      out += `\n`;
    }

    return reply(m, out);
  }

  /* ============ CARI PLUGIN ============ */
  const found = findPlugin(query);

  if (!found) {
    return reply(m,
`❌ Plugin *${query}* tidak ditemukan.

💡 Coba:
• Ketik \`${prefix}${command}\` buat liat semua plugin
• Atau cek nama command/filenya`);
  }

  if (!fs.existsSync(found.file)) {
    return reply(m, `❌ File plugin tidak ada di disk:\n\`${found.file}\``);
  }

  try {
    await sock.sendMessage(m.chat, { react: { text: "📦", key: m.key } });

    const buffer = fs.readFileSync(found.file);
    const filename = path.basename(found.file);
    const sizeKb = (buffer.length / 1024).toFixed(2);

    const caption =
`📦 *PLUGIN RETRIEVED*

📁 *Folder:* ${found.category}
📄 *File:* ${filename}
🎯 *Command:* ${found.commands.map(c => "`" + config.prefix + c + "`").join(", ")}
📊 *Size:* ${sizeKb} KB
📂 *Path:* \`${found.file.replace(/\\/g, "/").replace(process.cwd(), ".")}\`

✅ Copy file ini ke folder \`plugins/${found.category}/\` di SC lu.`;

    await sock.sendMessage(m.chat, {
      document: buffer,
      mimetype: "application/javascript",
      fileName: filename,
      caption
    }, { quoted: m.raw });

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (e) {
    console.error("[getplugin]", e);
    await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    reply(m, `❌ Gagal kirim plugin: ${e.message}`);
  }
}

export default {
  handle,
  Commands: ["getplugin", "gp", "ambilplugin"],
  OnlyPremium: false,
  OnlyOwner: true
};