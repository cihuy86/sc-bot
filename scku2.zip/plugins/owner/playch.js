'use strict';

import axios from "axios";
import {
  proto,
  prepareWAMessageMedia,
  generateMessageIDV2
} from "@sairidev/baileys-new";

import { reply, isOwner as _isOwner } from "../../lib/utils.js";
import { searchYoutube, downloadYoutube, Toptt } from "../../lib/youtube.js";
import { rich } from "../../lib/rich.js";
import { pendingPlaych } from "../../lib/pendingState.js";
import config from "../../config.js";

/* ============================================================ */
/* ============ MAIN HANDLER ============ */
/* ============================================================ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;

  const client = sock;
  const text = (args || []).join(" ").trim();
  const isOwner = _isOwner(m);
  const isPremium = false;
  const zreply = (t) => reply(m, t);

  // ============================================================
  // ============ CODE ASLI LU — GAK DIUBAH ============
  // ============================================================
  {
    if (!isOwner && !isPremium) {
      return zreply(global.mess.premium);
    }

    let totalSeparator = (text.match(/\|/g) || []).length;

    if (totalSeparator === 1 || totalSeparator === 0) {
      let queryText = text.split("|")[0]?.trim();
      let channelIdInput = text.split("|")[1]?.trim();

      if (!queryText || !channelIdInput || !channelIdInput.endsWith('@newsletter')) {
        return zreply(`— ex: ${config.prefix}${command} <song> | <id_channel>`);
      }

      await client.sendMessage(m.chat, { react: { text: "🔍", key: m.key } });

      try {
        const searchResults = await searchYoutube(queryText);
        const topResults = searchResults.slice(0, 10);

        pendingPlaych.set(m.chat, {
          results: topResults,
          channelId: channelIdInput,
          queryText,
          createdAt: Date.now()
        });

        const menuCarousel = new rich.Carousel(client);
        const cards = [];
        let rank = 1;

        for (const item of topResults) {
          try {
            const songCard = await new rich.Button(client)
              .setTitle(item.title)
              .setBody(`${item.channel} • ${item.duration}`)
              .setFooter(`Page: ${rank++}`)
              .setImage(item.imageUrl)
              .addReply("Pilih", `${rank}`)
              .toCard();

            cards.push(songCard);
          } catch (cardErr) {
            rank++;
            continue;
          }
        }

        if (cards.length === 0) {
          throw new Error("Gagal memuat komponen kartu interaktif.");
        }

        await menuCarousel
          .setBody(`🎵 *YOUTUBE PLAY CHANNEL*\n\n🔎 Hasil Pencarian: *${queryText}*\n📢 Target Channel: *${channelIdInput}*`)
          .addCard(cards)
          .send(m.chat, { quoted: m.raw });

        await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

      } catch (e) {
        console.error(e);
        await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        zreply(`❌ Error: ${e.message}`);
      }
    }
    else if (text.startsWith("action|send|") || totalSeparator === 3) {
      let rawText = text.startsWith("action|send|") ? text.replace("action|send|", "") : text;
      let [queryText, thumbUrl, channelName, channelId] = rawText.split("|").map(v => v ? v.trim() : "");

      if (!channelId || !channelId.endsWith('@newsletter')) {
        return zreply('❌ Error: ID Channel target tidak valid!');
      }

      await processSendToChannel(sock, m, zreply, {
        queryText,
        channelName,
        channelId
      });
    }
  }
  // ============================================================
  // ============ END CODE ASLI ============
  // ============================================================
}

/* ============================================================ */
/* ============ PROSES KIRIM KE CHANNEL ============ */
/* ============================================================ */
async function processSendToChannel(sock, m, zreply, { queryText, channelName, channelId }) {
  const client = sock;

  try {
    await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const searchResults = await searchYoutube(queryText);
    const firstVideo = searchResults[0];

    if (!firstVideo || !firstVideo.link) {
      throw new Error("Gagal mendapatkan link video untuk diunduh.");
    }

    const audioResult = await downloadYoutube(firstVideo.link);
    const title = audioResult.title || queryText;
    const rawBuffer = audioResult.buffer;

    if (!rawBuffer || rawBuffer.length < 1000) {
      throw new Error("File audio kosong atau korup");
    }

    console.log(`[playch] audio size: ${(rawBuffer.length / 1024 / 1024).toFixed(2)} MB (source: ${audioResult.source || "unknown"})`);

    const pttBuffer = await Toptt(rawBuffer);

    let preparedAudio = await prepareWAMessageMedia({
      audio: pttBuffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true
    }, { upload: client.waUploadToServer, jid: channelId });

    let audioMsgPayload = {
      audioMessage: {
        ...preparedAudio.audioMessage,
        ptt: true,
        mimetype: 'audio/ogg; codecs=opus',
        waveform: new Uint8Array([100, 80, 60, 100, 40, 80, 100, 50])
      }
    };

    let node = {
      tag: 'message',
      attrs: {
        to: channelId,
        id: (typeof generateMessageIDV2 === 'function' ? generateMessageIDV2() : m.key.id),
        type: 'media',
      },
      content: [{
        tag: 'plaintext',
        attrs: { mediatype: 'audio' },
        content: proto.Message.encode(audioMsgPayload).finish()
      }]
    };

    await client.query(node);

    await client.sendMessage(m.chat, {
      text: `✅ *Audio Berhasil Dikirim ke Channel!*\n\n🎵 *Judul:* ${title}\n📺 *Channel:* ${channelName || "YouTube"}\n🔗 *Link:* ${firstVideo.link}`,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: global.newsletter.id,
          newsletterName: global.newsletter.name,
          serverMessageId: 1
        }
      }
    }, { quoted: m.raw });

    await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (err) {
    console.error("Critical Relay Audio Error:", err);
    await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    zreply(`❌ Gagal memproses audio ke channel: ${err.message}`);
  }
}

/* ============================================================ */
/* ============ HANDLE PENDING ============ */
/* ============================================================ */
async function handlePending(sock, m, pending) {
  const body = (m.body || "").trim().toLowerCase();

  if (body === "cancel") {
    try { await reply(m, "❌ Dibatalkan."); } catch {}
    return true;
  }

  const num = parseInt(body, 10);
  if (isNaN(num) || num < 1 || num > pending.results.length) {
    return false;
  }

  const selected = pending.results[num - 1];
  const channelId = pending.channelId;

  console.log("[playch] selected:", JSON.stringify({
    title: selected.title,
    videoId: selected.videoId,
    link: selected.link,
    channelId
  }));

  const zreply = (t) => reply(m, t);

  await processSendToChannel(sock, m, zreply, {
    queryText: selected.title,
    channelName: selected.channel,
    channelId
  });

  return true;
}

export default {
  handle,
  handlePending,
  Commands: ["playch"],
  OnlyOwner: true
};