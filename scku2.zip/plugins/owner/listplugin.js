'use strict';

import { reply } from "../../lib/utils.js";
import config from "../../config.js";
import { pluginList } from "../../lib/pluginHandler.js";

async function handle(sock, messageInfo) {
  const { m } = messageInfo;
  const prefix = config.prefix || ".";

  if (pluginList.length === 0) {
    return reply(m, "📭 Belum ada plugin yang ke-load.");
  }

  const grouped = {};
  for (const entry of pluginList) {
    const cat = entry.category || "other";
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(entry);
  }

  let out = `╭─────────────────────────────╮\n`;
  out += `│   📦 *DAFTAR PLUGIN*\n`;
  out += `╰─────────────────────────────╯\n\n`;

  for (const cat of Object.keys(grouped).sort()) {
    out += `📁 *${cat.toUpperCase()}*\n`;
    for (const entry of grouped[cat]) {
      const flag = entry.plugin.OnlyOwner ? " 🔒" : "";
      out += `  ◦ \`${prefix}${entry.primary}\`${flag}\n`;
    }
    out += `\n`;
  }

  out += `📊 Total: *${pluginList.length}* plugin\n`;
  out += `🔒 = owner only`;

  await reply(m, out);
}

export default {
  handle,
  Commands: ["listplugin", "lp", "plugins"],
  OnlyOwner: true
};