'use strict';

import { reply, isOwner } from "../../lib/utils.js";
import config from "../../config.js";

/* ============ AMBIL TEXT DARI PESAN YANG DI-REPLY ============ */
function getQuotedText(m) {
  const q = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!q) return "";

  return (
    q.conversation ||
    q.extendedTextMessage?.text ||
    q.imageMessage?.caption ||
    q.videoMessage?.caption ||
    q.documentMessage?.caption ||
    q.audioMessage?.caption ||
    ""
  );
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) {
    return reply(m, "🔒 _Command ini khusus owner._");
  }

  if (!m.isGroup) {
    return reply(m, "⚠️ Fitur ini cuma bisa dipakai di grup.");
  }

  const q = (args || []).join(" ").trim();

  let messageText = q;
  if (!messageText) messageText = getQuotedText(m);

  if (!messageText) {
    return reply(m,
`⚠️ *Format salah.*

*Cara pakai:*
• \`${prefix}${command} <teks>\` — kirim teks + tag semua member
• Reply pesan apa aja → \`${prefix}${command}\` — kirim ulang pesannya + tag semua member

*Contoh:*
• \`${prefix}${command} Halo semua\``);
  }

  /* ============ AMBIL SEMUA MEMBER GRUP ============ */
  let participants = [];
  try {
    const meta = await sock.groupMetadata(m.chat);
    participants = meta?.participants || [];
  } catch (e) {
    console.error("[hidetag] gagal ambil metadata:", e.message);
    return reply(m, "❌ Gagal ambil data grup. Coba lagi.");
  }

  const members = participants.map((p) => p.id);

  if (!members.length) {
    return reply(m, "⚠️ Grup ini gak ada member.");
  }

  /* ============ KIRIM PESAN + MENTION SEMUA ============ */
  try {
    await sock.sendMessage(m.chat, {
      text: messageText,
      mentions: members
    }, { quoted: m.raw });

    console.log(`[hidetag] sent to ${members.length} members in ${m.chat}`);
  } catch (e) {
    console.error("[hidetag] error:", e);
    await reply(m, `❌ Gagal kirim: ${e.message}`);
  }
}

export default {
  handle,
  Commands: ["ht", "hidetag", "h"],
  OnlyPremium: false,
  OnlyOwner: true
};