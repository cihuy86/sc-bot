'use strict';

import { reply, isOwner } from "../../lib/utils.js";
import config from "../../config.js";

function extractInviteCode(text) {
  if (!text) return null;
  const m = text.match(/whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i);
  return m ? m[1] : null;
}

function extractChannelJid(m) {
  const c = m.message?.extendedTextMessage?.contextInfo
         || m.message?.imageMessage?.contextInfo
         || m.message?.videoMessage?.contextInfo
         || m.message?.audioMessage?.contextInfo;
  if (!c) return null;
  const info = c.forwardedNewsletterMessageInfo;
  if (info && info.newsletterJid?.endsWith("@newsletter")) {
    return { jid: info.newsletterJid, name: info.newsletterName || "-" };
  }
  if (c.participant?.endsWith("@newsletter")) return { jid: c.participant, name: "-" };
  if (c.remoteJid?.endsWith("@newsletter")) return { jid: c.remoteJid, name: "-" };
  return null;
}

async function fetchViaInvite(sock, code) {
  try {
    if (typeof sock.newsletterMetadata !== "function") {
      return { ok: false, error: "Method newsletterMetadata tidak ada di library" };
    }
    const meta = await sock.newsletterMetadata("invite", code);
    if (meta && (meta.id || meta.jid)) return { ok: true, meta };
    return { ok: false, error: "Metadata null/empty" };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function fetchViaJid(sock, jid) {
  try {
    if (typeof sock.newsletterMetadata !== "function") return null;
    return await sock.newsletterMetadata("jid", jid);
  } catch (e) {
    console.error("metadata jid error:", e.message);
    return null;
  }
}

async function handle(sock, messageInfo) {
  const { m, args } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) return reply(m, "🔒 _Command ini khusus owner._");

  const text = (args || []).join(" ").trim();

  /* MODE 1: LINK */
  if (text) {
    const code = extractInviteCode(text);
    if (!code) {
      return reply(m, `⚠️ Format: \`${prefix}cekidch <link channel>\``);
    }

    await sock.sendMessage(m.chat, { react: { text: "🔍", key: m.key } });

    const res = await fetchViaInvite(sock, code);
    if (!res.ok) {
      await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return reply(m,
`❌ *Gagal ambil metadata.*

Code: \`${code}\`

Error:
\`\`\`
${res.error}
\`\`\`

💡 Coba *Cara 2*: forward/reply pesan dari channel → \`${prefix}cekidch\``);
    }

    const meta = res.meta;
    const jid = meta.id || meta.jid || "-";
    const name = meta.name?.text || meta.name || meta.thread_metadata?.name?.text || meta.thread_metadata?.name || "-";
    const subs = meta.subscribers ?? meta.subscriberCount ?? meta.thread_metadata?.subscribers_count ?? "-";
    const finalJid = String(jid).endsWith("@newsletter") ? jid : `${jid}@newsletter`;

    await reply(m,
`📢 *INFO CHANNEL*

🆔 *ID / JID*  : \`${finalJid}\`
📛 *Nama*      : ${name}
👥 *Subscriber*: ${subs}

📋 *Copy ke playch:*
\`${finalJid}\``);
    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    return;
  }

  /* MODE 2: REPLY/FORWARD */
  const fromCtx = extractChannelJid(m);
  if (fromCtx) {
    await sock.sendMessage(m.chat, { react: { text: "🔍", key: m.key } });
    let name = fromCtx.name;
    let subs = "-";
    const meta = await fetchViaJid(sock, fromCtx.jid);
    if (meta) {
      name = meta.name?.text || meta.name || meta.thread_metadata?.name?.text || name;
      subs = meta.subscribers ?? meta.subscriberCount ?? "-";
    }
    await reply(m,
`📢 *INFO CHANNEL*

🆔 \`${fromCtx.jid}\`
📛 ${name}
👥 ${subs}

📋 Copy ke playch: \`${fromCtx.jid}\``);
    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    return;
  }

  return reply(m,
`📢 *CEK ID CHANNEL*

*Cara 1 (link)* → \`${prefix}cekidch <link>\`
*Cara 2 (reply/forward)* → reply pesan dari channel → \`${prefix}cekidch\``);
}

export default {
  handle,
  Commands: ["cekidch", "chid", "idch", "channelid"],
  OnlyOwner: true
};