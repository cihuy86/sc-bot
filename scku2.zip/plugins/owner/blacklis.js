'use strict';

import {
  addBlacklist,
  removeBlacklist,
  listBlacklist,
  clearBlacklist,
  isBlacklisted
} from "../../lib/blacklist.js";
import { reply, isOwner } from "../../lib/utils.js";
import config from "../../config.js";

/* ============ AMBIL NAMA GRUP ============ */
async function getGroupName(sock, jid) {
  try {
    const meta = await sock.groupMetadata(jid);
    return meta?.subject || "";
  } catch {
    return "";
  }
}

/* ============ HANDLE ============ */
async function handle(sock, messageInfo) {
  const { m, args } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) return reply(m, "🔒 _Command ini khusus owner._");

  const sub = (args[0] || "").toLowerCase();
  const target = args[1] || "";

  /* ===== LIST ===== */
  if (!sub || sub === "list") {
    const list = listBlacklist();
    if (!list.length) {
      return reply(m,
`📋 *BLACKLIST GRUP*

Belum ada grup yang di-blacklist.

*Cara pakai:*
• \`${prefix}blacklist add <link/jid>\`
• \`${prefix}blacklist del <link/jid>\`
• \`${prefix}blacklist check\` (di grup ini)
• \`${prefix}blacklist clear\` (hapus semua)`);
    }

    let out = `📋 *BLACKLIST GRUP* (${list.length})\n\n`;
    list.forEach((g, i) => {
      const name = g.name || "(tanpa nama)";
      const date = new Date(g.addedAt).toLocaleString("id-ID");
      out += `*${i + 1}.* ${name}\n`;
      out += `    🆔 \`${g.jid}\`\n`;
      out += `    📅 ${date}\n\n`;
    });
    out += `> Total: ${list.length} grup`;
    return reply(m, out);
  }
  /* ===== ADD ===== */
  if (sub === "add") {
    let jid = extractJid(target);

    // kalau gak ada target, pakai grup saat ini
    if (!jid && m.isGroup) jid = m.chat;

    if (!jid) {
      return reply(m,
`⚠️ Format salah.

*Cara pakai:*
• Di dalam grup → \`${prefix}blacklist add\`
• Dari luar → \`${prefix}blacklist add <JID grup>\`
• Atau: \`${prefix}blacklist add 123xxx@g.us\``);
    }

    // cek apakah JID valid @g.us
    if (!jid.endsWith("@g.us")) {
      return reply(m, `⚠️ JID tidak valid: \`${jid}\`\n\nHarus berakhir dengan \`@g.us\``);
    }

    const name = await getGroupName(sock, jid);
    const res = addBlacklist(jid, {
      by: m.sender,
      name
    });

    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *Berhasil di-blacklist!*

📛 Nama : ${name || "-"}
🆔 JID  : \`${jid}\`

Bot gak akan respon command di grup ini.`);
  }

  /* ===== DEL ===== */
  if (sub === "del" || sub === "remove" || sub === "unbl") {
    let jid = extractJid(target);

    // kalau gak ada target, pakai grup saat ini
    if (!jid && m.isGroup) jid = m.chat;

    if (!jid) {
      return reply(m,
`⚠️ Format salah.

*Cara pakai:*
• Di dalam grup → \`${prefix}blacklist del\`
• Dari luar → \`${prefix}blacklist del <link grup>\`
• Atau JID langsung: \`${prefix}blacklist del 123xxx@g.us\``);
    }

    const res = removeBlacklist(jid);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *Berhasil dilepas dari blacklist!*

🆔 JID : \`${jid}\`

Bot udah bisa respon command lagi di grup ini.`);
  }

  /* ===== CHECK ===== */
  if (sub === "check") {
    if (!m.isGroup) {
      return reply(m, "⚠️ Command ini cuma bisa dipakai di dalam grup.");
    }
    const status = isBlacklisted(m.chat);
    const name = await getGroupName(sock, m.chat);
    return reply(m,
`📊 *STATUS GRUP*

📛 Nama   : ${name || "-"}
🆔 JID    : \`${m.chat}\`
🔒 Status : ${status ? "BLACKLISTED ❌" : "AKTIF ✅"}`);
  }

  /* ===== CLEAR ===== */
  if (sub === "clear") {
    clearBlacklist();
    return reply(m, "✅ Semua blacklist grup berhasil dihapus.");
  }

  /* ===== FALLBACK ===== */
  return reply(m,
`⚠️ Sub-command tidak dikenal.

*Yang tersedia:*
• \`${prefix}blacklist\` — lihat daftar
• \`${prefix}blacklist add [link/jid]\` — tambah
• \`${prefix}blacklist del [link/jid]\` — hapus
• \`${prefix}blacklist check\` — cek grup ini
• \`${prefix}blacklist clear\` — hapus semua`);
}

/* ============ EXTRACT JID ============ */
function extractJid(input) {
  if (!input) return null;

  // langsung JID
  if (input.endsWith("@g.us")) return input;

  // link grup: https://chat.whatsapp.com/XXXXX
  const linkMatch = input.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
  if (linkMatch) {
    // link gak bisa langsung dapet JID tanpa join — kasih tau user
    // Jadi kita return null biar user pakai cara lain
    return null;
  }

  // nomor grup? format 62xxx-xxx
  if (/^\d{10,}$/.test(input)) {
    return input + "@g.us";
  }

  return null;
}

export default {
  handle,
  Commands: ["blacklist", "bl"],
  OnlyOwner: true
};