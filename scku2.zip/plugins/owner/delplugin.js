'use strict';

import fs from "fs";
import path from "path";
import { reply } from "../../lib/utils.js";
import config from "../../config.js";
import { plugins, pluginList, unloadPluginByCommand } from "../../lib/pluginHandler.js";
import { isOwner } from "../../lib/utils.js";

async function handle(sock, messageInfo) {
  const { m, args } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) return reply(m, "🔒 _Command ini khusus owner._");

  if (!args || !args[0]) {
    return reply(m,
`⚠️ *Format salah.*

Gunakan:
• \`${prefix}delplugin <folder>/<nama>\` → hapus by file
• \`${prefix}delplugin <command>\` → hapus by command

Contoh:
• \`${prefix}delplugin game/racing\`
• \`${prefix}delplugin racing\`
• \`${prefix}delplugin owner/swgc\``);
  }

  const target = args[0].trim();
  let filePath = null;
  let entryToRemove = null;

  if (/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+/.test(target)) {
    const [folder, name] = target.split("/");
    const filename = name.endsWith(".js") ? name : `${name}.js`;
    filePath = path.join("./plugins", folder, filename);
  } else {
    const entry = plugins.get(target.toLowerCase());
    if (entry) {
      entryToRemove = entry;
      filePath = entry.file;
    }
  }

  if (!filePath || !fs.existsSync(filePath)) {
    return reply(m, `❌ Plugin \`${target}\` tidak ditemukan.`);
  }

  // ===== UNREGISTER DULU =====
  if (entryToRemove) {
    unloadPluginByCommand(entryToRemove.primary);
  } else {
    const e = pluginList.find((p) => p.file === filePath);
    if (e) unloadPluginByCommand(e.primary);
  }

  try {
    fs.unlinkSync(filePath);
    const normalized = filePath.replace(/\\/g, "/");
    await reply(m, `✅ Plugin \`${normalized}\` berhasil dihapus.`);
  } catch (e) {
    await reply(m, `❌ Gagal hapus: ${e.message}`);
  }
}

export default {
  handle,
  Commands: ["delplugin", "dp"],
  OnlyOwner: true
};