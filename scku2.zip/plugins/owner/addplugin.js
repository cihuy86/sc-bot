'use strict';

import { reply } from "../../lib/utils.js";
import config from "../../config.js";
import { pendingAddPlugin } from "../../lib/pendingState.js";

async function handle(sock, messageInfo) {
  const { m, args } = messageInfo;
  const prefix = config.prefix || ".";

  if (!args || !args[0]) {
    return reply(m,
`⚠️ *Format salah.*

Gunakan: \`${prefix}addplugin <folder>/<nama>\`

Contoh:
• \`${prefix}addplugin game/racing\`
• \`${prefix}addplugin tools/translate\`

Nanti bot minta lu kirim kode plugin-nya.`);
  }

  const target = args[0].trim();
  if (!/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+$/.test(target)) {
    return reply(m, "⚠️ Format harus `folder/nama` (contoh: `game/racing`). Hanya huruf, angka, `_`, `-`.");
  }

  const [folder, name] = target.split("/");
  const filename = name.endsWith(".js") ? name : `${name}.js`;

  // cek kalau udah ada
  const checkPath = `./plugins/${folder}/${filename}`;
  try {
    const fs = await import("fs");
    if (fs.existsSync(checkPath)) {
      return reply(m, `⚠️ File \`plugins/${folder}/${filename}\` sudah ada. Hapus dulu pakai \`${prefix}delplugin ${folder}/${name}\`.`);
    }
  } catch {}

  pendingAddPlugin.set(m.chat, {
    folder,
    filename,
    createdAt: Date.now()
  });

  await reply(m,
`📝 *Mode tambah plugin aktif.*

🎯 Target: \`plugins/${folder}/${filename}\`

Sekarang *kirim kode plugin* lu di chat ini.

⏱️ Timeout 5 menit.
Ketik \`cancel\` untuk batal.`);
}

export default {
  handle,
  Commands: ["addplugin", "ap"],
  OnlyOwner: true
};