'use strict';

import { reply, isOwner } from "../../lib/utils.js";
import { addOwner, removeOwner, listOwners, detectType } from "../../lib/owners.js";
import config from "../../config.js";

/* ============ HELPER: AMBIL JID DARI REPLY ============ */
function getQuotedSenderJid(m) {
  const msg = m.message || {};

  const ctx =
    msg.extendedTextMessage?.contextInfo ||
    msg.imageMessage?.contextInfo ||
    msg.videoMessage?.contextInfo ||
    msg.audioMessage?.contextInfo ||
    msg.documentMessage?.contextInfo ||
    msg.stickerMessage?.contextInfo ||
    msg.contactMessage?.contextInfo ||
    msg.locationMessage?.contextInfo;

  if (!ctx) return null;

  // participant = JID orang yang di-reply (di grup)
  // kalau di DM, participant kosong → pakai remoteJid
  const jid = ctx.participant || ctx.remoteJid || null;

  if (!jid) return null;

  // jangan ambil kalau yang di-reply pesan bot sendiri
  if (jid === "status@broadcast") return null;

  return jid;
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const prefix = config.prefix || ".";

  if (!isOwner(m)) return reply(m, "🔒 _Command ini khusus owner._");

  const cmd = (command || "").toLowerCase();
  const input = (args || []).join(" ").trim();

  /* ==================== .addowner ==================== */
  if (cmd === "addowner" || cmd === "ao") {
    let target = input;
    let source = "input manual";

    // kalau gak ada input, coba ambil dari reply
    if (!target) {
      const quotedJid = getQuotedSenderJid(m);
      if (quotedJid) {
        target = quotedJid;
        source = "reply pesan";
      }
    }

    if (!target) {
      return reply(m,
`⚠️ *Format salah.*

*Cara pakai:*
1️⃣ Reply pesan orang → \`${prefix}addowner\`
2️⃣ Atau ketik manual → \`${prefix}addowner <nomor/LID>\`

*Contoh manual:*
• \`${prefix}addowner 6281234567890\`
• \`${prefix}addowner 126538628497614\`

💡 Kalau reply pesan, pastiin reply chat orang (bukan chat bot).`);
    }

    const detected = detectType(target);
    if (!detected) {
      return reply(m,
`❌ Gak bisa deteksi tipe.

Yang lu masukin: \`${target}\`

Nomor HP: 10-13 digit
LID: 14+ digit

_Sumber: ${source}_`);
    }

    const res = addOwner(target, detected);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *Owner ditambahkan!*

📞 Tipe: *${res.type === "number" ? "Nomor HP" : "LID"}*
🔢 Value: \`${res.value}\`
📍 Sumber: ${source}

💡 Cek log terminal buat liat status match.`);
  }

  /* ==================== .delowner ==================== */
  if (cmd === "delowner" || cmd === "do" || cmd === "removeowner") {
    let target = input;
    let source = "input manual";

    // kalau gak ada input, coba ambil dari reply
    if (!target) {
      const quotedJid = getQuotedSenderJid(m);
      if (quotedJid) {
        target = quotedJid;
        source = "reply pesan";
      }
    }

    if (!target) {
      return reply(m,
`⚠️ *Format salah.*

*Cara pakai:*
1️⃣ Reply pesan orang → \`${prefix}delowner\`
2️⃣ Atau ketik manual → \`${prefix}delowner <nomor/LID>\``);
    }

    const res = removeOwner(target);
    if (!res.ok) return reply(m, `❌ ${res.error}`);

    return reply(m,
`✅ *Owner dihapus!*

📞 Tipe: *${res.type === "number" ? "Nomor HP" : "LID"}*
🔢 Value: \`${res.value}\`
📍 Sumber: ${source}`);
  }

  /* ==================== .listowner ==================== */
  if (cmd === "listowner" || cmd === "lo" || cmd === "owner" || cmd === "owners") {
    const data = listOwners();

    let out = `👑 *DAFTAR OWNER*\n\n`;

    const hasConfig = data.configNumbers.length || data.configLids.length;
    const hasFile = data.fileNumbers.length || data.fileLids.length;

    if (hasConfig) {
      out += `📌 *Dari config.js:*\n`;
      data.configNumbers.forEach((n, i) => out += `  ${i + 1}. \`${n}\` (nomor)\n`);
      data.configLids.forEach((l, i) => out += `  ${i + 1}. \`${l}\` (LID)\n`);
      out += `\n`;
    }

    if (hasFile) {
      out += `📌 *Dari .addowner:*\n`;
      data.fileNumbers.forEach((n, i) => out += `  ${i + 1}. \`${n}\` (nomor)\n`);
      data.fileLids.forEach((l, i) => out += `  ${i + 1}. \`${l}\` (LID)\n`);
      out += `\n`;
    }

    if (!hasConfig && !hasFile) {
      out += `_Belum ada owner._\n\n`;
    }

    out += `━━━━━━━━━━━━━━━━━━\n`;
    out += `*Total:* ${data.configNumbers.length + data.configLids.length + data.fileNumbers.length + data.fileLids.length} owner\n\n`;
    out += `*Command:*\n`;
    out += `• \`${prefix}addowner <nomor/LID>\`\n`;
    out += `• \`${prefix}addowner\` _(reply pesan)_\n`;
    out += `• \`${prefix}delowner <nomor/LID>\`\n`;
    out += `• \`${prefix}listowner\``;

    return reply(m, out);
  }

  return reply(m,
`⚠️ Sub-command tidak dikenal.

*Yang tersedia:*
• \`${prefix}addowner <nomor/LID>\`
• \`${prefix}delowner <nomor/LID>\`
• \`${prefix}listowner\``);
}

export default {
  handle,
  Commands: ["addowner", "delowner", "listowner", "owner", "owners"],
  OnlyPremium: false,
  OnlyOwner: true
};