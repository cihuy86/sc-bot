'use strict';

import axios from 'axios';
import config from '../../config.js';
import { reply } from '../../lib/utils.js';

/*
 * FAKE FF DUO
 * Base API : https://apii.nexadev.my.id/fakeffduo
 * Type : ESM Plugin
 */

async function handle(sock, messageInfo) {
  const { m, args, command } = messageInfo;
  const conn = sock;
  const text = (args || []).join(' ').trim();

  // ============================================================
  // ============ CODE ASLI LU — GAK DIUBAH ============
  // ============================================================
  try {
    if (!text) {
      return m.reply(`❌ *NICKNAME TIDAK BOLEH KOSONG*

Format:
${config.prefix}${command} nickname1|nickname2`);
    }

    const argArr = text.split('|');

    if (argArr.length < 2) {
      return m.reply(`❌ *FORMAT SALAH*

Gunakan:
${config.prefix}${command} nickname1|nickname2`);
    }

    const nickname1 = argArr[0].trim();
    const nickname2 = argArr.slice(1).join('|').trim();

    if (!nickname1 || !nickname2) {
      return m.reply('❌ Kedua nickname wajib diisi.');
    }

    if (nickname1.length > 30 || nickname2.length > 30) {
      return m.reply('❌ Maksimal 30 karakter untuk setiap nickname.');
    }

    await m.reply('⏳ Sedang membuat Fake FF Duo...');

    const apiUrl = `https://apii.nexadev.my.id/fakeffduo?nickname1=${encodeURIComponent(nickname1)}&nickname2=${encodeURIComponent(nickname2)}`;

    const response = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
      timeout: 60000,
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'image/*'
      },
      maxContentLength: 15 * 1024 * 1024,
      maxBodyLength: 15 * 1024 * 1024
    });

    if (!response.data || response.data.length === 0) {
      return m.reply('❌ API tidak mengembalikan gambar.');
    }

    const contentType = response.headers['content-type'] || '';

    if (!contentType.startsWith('image/')) {
      let errorText;

      try {
        errorText = Buffer.from(response.data).toString('utf8');
      } catch {
        errorText = 'Response API bukan gambar.';
      }

      return m.reply(`❌ *GAGAL MEMBUAT FAKE FF DUO*

${errorText.substring(0, 1000)}`);
    }

    await conn.sendMessage(
      m.chat,
      {
        image: Buffer.from(response.data),
        caption: `🎮 *FAKE FREE FIRE DUO*

👤 Player 1: ${nickname1}
👤 Player 2: ${nickname2}`
      },
      { quoted: m.raw }
    );
  } catch (e) {
    console.log('FAKEFFDUO ERROR:', e);

    let errorMessage =
      e.response?.data?.message ||
      e.response?.data?.msg ||
      e.message ||
      'Terjadi kesalahan tidak diketahui.';

    if (e.code === 'ECONNABORTED' || e.code === 'ETIMEDOUT') {
      errorMessage = 'Request API timeout. Silakan coba lagi.';
    }

    if (e.response?.status === 404) {
      errorMessage = 'Endpoint Fake FF Duo tidak ditemukan (404).';
    }

    if (e.response?.status === 429) {
      errorMessage = 'Terlalu banyak request. Tunggu beberapa saat.';
    }

    return m.reply(`❌ *FAKE FF DUO ERROR*

${errorMessage}`);
  }
  // ============================================================
  // ============ END CODE ASLI ============
  // ============================================================
}

export default {
  handle,
  Commands: ['fakeffduo'],
  OnlyPremium: false,
  OnlyOwner: false
};