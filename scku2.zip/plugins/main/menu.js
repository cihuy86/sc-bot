'use strict';

import config from "../../config.js";
import { pluginList } from "../../lib/pluginHandler.js";
import { runtime } from "../../lib/utils.js";

const CATEGORY_ICON = {
  main: "🏠", game: "🎮", games: "🎮",
  download: "📥", downloader: "📥",
  tools: "🛠️", tool: "🛠️",
  media: "🎬", music: "🎵",
  ai: "🤖", owner: "👑",
  sticker: "🎨", stiker: "🎨",
  group: "👥", search: "🔍",
  utility: "🧰", fun: "🎉",
  other: "📦"
};

/* ============ BUILD MENU TEXT ============ */
function buildMenuText(m, uptimeSec) {
  const grouped = {};
  for (const entry of pluginList) {
    const cat = entry.category || "other";
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(entry.primary);
  }

  const total = pluginList.length;
  let out = "";
  out += `╭─────────────────────────────╮\n`;
  out += `│   ✦  *${config.botName}*  ✦\n`;
  out += `╰─────────────────────────────╯\n\n`;
  out += `  👤 Nama    : ${m.pushName || "-"}\n`;
  out += `  🕐 Runtime : ${runtime(uptimeSec)}\n`;
  out += `  🧩 Plugin  : ${total} command\n`;
  out += `  ⚡ Prefix  : ${config.prefix}\n\n`;

  for (const cat of Object.keys(grouped).sort()) {
    const icon = CATEGORY_ICON[cat] || "📦";
    out += `╭─ ${icon} *${cat.toUpperCase()}*\n`;
    for (const cmd of grouped[cat]) {
      out += `│  ◦ ${config.prefix}${cmd}\n`;
    }
    out += `╰─────────────────────────────\n\n`;
  }

  out += `> 💡 Tap tombol di bawah buat akses cepet`;
  return out;
}

/* ============ HANDLER ============ */
async function handle(sock, messageInfo) {
  const { m } = messageInfo;
  const uptimeSec = Math.floor((Date.now() - globalThis.__startTime) / 1000);

  const text = buildMenuText(m, uptimeSec);

  try {
    // 1. Kirim text menu lengkap
    await m.reply(text);

    // 2. Kirim button menu utama (DYNAMIC)
    // import buildMenu dari buttonHandler
    const { buildMenu } = await import("../../lib/buttonHandler.js");
    const menu = buildMenu("main");

    if (!menu.buttons.length) return;

    const buttons = menu.buttons.map((b) => ({
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: b.text,
        id: `❰ 🎯 ＢＴＮ ❱ ${b.id}`
      })
    }));

    const interactiveMsg = {
      header: { title: menu.title, hasMediaAttachment: false },
      body: { text: menu.body },
      footer: { text: menu.footer || config.botName },
      nativeFlowMessage: { buttons }
    };

    // coba format 1
    try {
      await sock.relayMessage(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: interactiveMsg
          }
        }
      }, { quoted: m.raw });
      return;
    } catch {}

    // format 2
    try {
      await sock.relayMessage(m.chat, {
        botForwardedMessage: { message: { interactiveMessage: interactiveMsg } }
      }, { quoted: m.raw });
      return;
    } catch {}

    // format 3
    try {
      await sock.relayMessage(m.chat, { interactiveMessage: interactiveMsg }, { quoted: m.raw });
      return;
    } catch {}

  } catch (e) {
    console.error("menu error:", e);
  }
}

export default {
  handle,
  Commands: ["menu", "help", "commands"],
  OnlyPremium: false,
  OnlyOwner: false
};