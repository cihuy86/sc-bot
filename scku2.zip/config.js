export default {
  botName: "SIX CORE BOT",
  ownerName: "Owner",

  ownerNumbers: [
    "6285604014238"
  ],

  ownerLids: [
    "126538628497614"
  ],

  prefix: ".",
  sessionDir: "./session",
  pairingNumber: "",
  timezone: "Asia/Jakarta",
  usePairingCode: true,
  allowSelfCommand: false,

  packname: "SIX CORE",
  author: "Six Core Bot",

  /* ============ ANTI-SPAM ============ */
  antiSpam: {
    enabled: true,
    maxCommands: 5,           // maksimal 5 command
    windowSeconds: 10,        // dalam 10 detik
    cooldownMinutes: 10,      // cooldown 10 menit
    bypassOwners: true,       // owner bebas spam
  },

  newsletter: {
    id: "120363424960621529@newsletter",
    name: "666 Core Family"
  }
};